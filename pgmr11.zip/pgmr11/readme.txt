FF-PGMR11 Project Files

The files condained within this folder and sub-folders represent the full project data
for the FF-PGMR11 Protocol Converter.  No warranty is offered or implied as to the
workability or suitability of this design or any of its sub-parts.

Use these data at your own risk.

Your mileage may vary.

Read the fine print.

And all that rot...

The filenames and folders are reasonably self-explanatory.  If you wish to make code changes
or port to another processor, you will need a suitable C-compiler.  There is a free license
available (at the time of this writing) for the Keil compiler that works on the SiLabs 8-bit
MCUs.  While I have experienced issues with the Keil editor and Debugger, it is generally a
decent enough tool.  It is certainly worth $free if you have nothing to start with.

The PCB layout is provided in CAM/PDF format only (Gerbers and a PDF schematic).  If you
choose to build a design for the F340-DK, you can find part numbers in the pgmr11_bom.xls
spreadsheet but will need to reference the FFPGMR11_DK_schem.pdf schematic as there is no
dedicated BOM for the daughter card.

M68HC711E9PGMR_schem.pdf is a shcematic of the E9PGMR that was redrawing from the Motorola
USER'S MANUAL, HC711E9PGMR/AD1.  This document was located at the Freescale website circa
the publish date of this repository.  This document is a print-to-pdf and is of good quality
except for the schematic which was very poorly scanned at some point.  Most of the schematic
text is completely unreadable and it was necessary to perform ohmmeter checks of my E9PGMR
to confirm pin numbers.  The notations contained within this re-drawn schematic are paraphrased
from inferred intent.  Since they were largely unreadable, they could not be re-produced
exactly as the original.

This design is as complete a repository as I have been able to provide.  This simply means
that I have likely forgotten some important piece, but don't know it yet.  Any omissions
are purely un-intentional.

Enjoy.

Joe Haas
ke0ff
joeh@rollanet.org
12/21/2013
