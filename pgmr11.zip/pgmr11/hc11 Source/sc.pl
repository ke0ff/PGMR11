#!/usr/bin/perl -w
use Getopt::Long;
use Config;
use strict;

# sc.pl : s-record to byte-list conversion util.
# by Joe Haas, ke0ff (c) 2013, all rights reserved
# scans s-record file and extracts data bytes.  Character pairs (bytes)
# are placed in a c file with 8 bytes per line (format illustrated below).
# This script assumes that the S-record occupies a contiguous memory span
# (i.e., it ignores address gaps).  This script also ignores the s-record
# checksum.
#
# Useage:
#
#	sc.pl -source <filename> -dest <filename> -header <headername> -array <arrayname>
#
# Output:
#	U8 var[] = {
#			0xdd, 0xdd, 0xdd, 0xdd, 0xdd, 0xdd, 0xdd, 0xdd,
#			 :
#			0xdd, 0xdd, ...
#			}
#
# A DOS batch file would be used to convert multiple files in a design.
#
# main-scope vars & defaults:

my $in_path		= 't.c';		# (in filename == out filename) means print help
my $out_path	= 't.c';		# out filename
my $arrayn		= 'var';		# array name
my $header		= 'hc11_fns.h';	# hc11 default header file
my $rc = 1;						# in file status
my $maxline = 8;				# max # bytes per C line
my $perline = $maxline;			# bytes-per-line counter
my $lenline;					# s-rec data length counter
my $firstline = 1;				# first line trap
my $state = 0;					# fsm state reg
my $new;						# file input variable
my $old = "\n";					# previous file input (usu 1 chr) - start with newline
my $array_len = 0;				# array length counter

&GetOptions(
    "source=s"	=> \$in_path,	# define source path arg
	"dest=s"	=> \$out_path,	# define dest path arg
	"header=s"	=> \$header,	# header file path arg
	"array=s"	=> \$arrayn		# array name
);

if ($in_path =~ $out_path){
	# print useage help
	print "Useage: sc.pl -source <filename> -dest <filename> -header <headername> -array <arrayname>";
}else{
	print "Processing $in_path -> $out_path ... ";
	open(IN, "<$in_path") or die;
	open(OUT, ">$out_path") or die;
	# print c head info";
	print OUT "//\n";
	print OUT "#include \"typedef.h\"\n";
	print OUT "//\n";
	print OUT "code U8 $arrayn\[\] = {\n\t\t";
	while (($rc != 0) && ($state != 9)){
		# First, see if the byte is a "S" preceded by a cr or lf
		if ($state == 0){							# state 0 looks for start of S-line
			$rc = read IN, $new, 1, 0;
			if((ord($old) == 13) || (ord($old) == 10)){
				if ($new =~ m/S/){					# look for "S"
					$rc = read IN, $new, 1, 0;
					if ($new =~ m/1/){				# look for "1"
						$rc = read IN, $new, 1, 0;	# get length H
						$lenline = hex_dec($new) * 16;
						$rc = read IN, $new, 1, 0;	# get length L
						$lenline += hex_dec($new);
						$lenline -= 3;
						$array_len += $lenline;
						$rc = read IN, $new, 4, 0;	# get addr (then discard)
						if ($firstline != 1){
							print OUT ", \n\t\t";
						}
						$firstline = 0;
						$state = 1;
					}
					if ($new =~ m/9/){				# look for "9"
						$state = 9;					# set end state
					}
				}
			}
		}
		# get byte pairs and format for C
		if ($state == 1){							# state 1 is process S-line start
			$rc = read IN, $new, 2, 0;				# get ascii byte pair
			$lenline -= 1;							# byte count
			$perline -= 1;							# update bytes/line count
			print OUT "0x";							# format for C hex const
			print OUT $new;
			if ($lenline != 0){
				print OUT ", ";						# wait to print last seperator..
				if ($perline == 0){
					$perline = $maxline;
					print OUT "\n\t\t";
				}
			}else{
				if ($perline == 0){
					$perline = $maxline;
				}
				$state = 0;							# prep for next line
			}
		}
		# state 9 is implied state (part of while() exit criteria)
	} # end while
	print OUT "\n\t\t};\n";							# close array
	print OUT "//\n";
	print OUT "U8 $arrayn\_len\(void\)\{\n";		# insert function to return array length
	print OUT "\treturn (U8)sizeof\($arrayn\);\n";
	print OUT "}\n";
	print OUT "//\n";
	close(IN);
	close(OUT);
	open(OUT, ">>$header") or die;
	print OUT "extern code U8 $arrayn\[\];\n";		# add array extern to header file
	print OUT "U8 $arrayn\_len\(void\);\n";			# add array len fn declaration
	print OUT "#define $arrayn\_dlen $array_len\n";	# add array extern to header file
	close(OUT);
	print "conversion complete!\n";
} # end script

# Convert single hex digit to decimal.
sub hex_dec {
my $value;
my $chr;

	$chr = uc($_[0]);
	$value = $_[0];
    if ($chr =~ m/A/){ $value = 10;}
    if ($chr =~ m/B/){ $value = 11;}
    if ($chr =~ m/C/){ $value = 12;}
    if ($chr =~ m/D/){ $value = 13;}
    if ($chr =~ m/E/){ $value = 14;}
    if ($chr =~ m/F/){ $value = 15;}
	return $value;
} # end hex_dec

