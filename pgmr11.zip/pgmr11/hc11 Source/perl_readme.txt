Joe Haas
joeh@rollanet.org
KE0FF
12-07-2013

PERL Script Description File (perl_readme.txt)
Go to www.perl.org to get the latest PERL interpreter.  The scripts referenced
herein were developed and tested with PERL 5 on a WinXP machine.

sc.pl
This is an s-record to byte-list conversion utility.  It scans an s-record file
and extracts the data bytes.  The bytes are placed in a c file as ascii text character
pairs contained within a C-array definition with 8 bytes per line (format illustrated
below).  This script assumes that the S-record occupies a contiguous memory span
(i.e., it ignores address gaps between S-record lines), thus it is only applicable
to object data that occupies a contiguous memory space.  This script also ignores the s-record
checksum.

 Useage:

	sc.pl -source <filename> -dest <filename> -header <headername> -array <arrayname>

 Output:
	U8 <arrayname>[] = {
			0xdd, 0xdd, 0xdd, 0xdd, 0xdd, 0xdd, 0xdd, 0xdd,
			 :
			0xdd, 0xdd, ... , 0xdd
			}

	U8 <arrayname>_len(void){
	    return (U8)sizeof(<arrayname>);
	}

The U8 type is a #define in a C header file for the including C project:

#define U8                 unsigned char


A DOS batch file would be used to convert multiple files in a design.

#####################################################################################

incl.pl

Useage:

	incl.pl -incl <filename> -array <arrayname>

Output:
	#include "<arrayname>"

adds <arrayname> to <filename> as a C include line

