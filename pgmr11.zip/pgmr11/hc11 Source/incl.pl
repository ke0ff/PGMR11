#!/usr/bin/perl -w
use Getopt::Long;
use Config;
use strict;

# incl.pl : builds an include list
# by Joe Haas, ke0ff (c) 2013, all rights reserved
# adds arg2 to file arg1 as a C include line
#
# Useage:
#
#	incl.pl -incl <filename> -array <arrayname>
#
# main-scope vars & defaults:

my $out_path	= 't.c';		# out filename
my $arrayn		= 't.c';		# array name
my $header;

&GetOptions(
	"incl=s"	=> \$out_path,	# define dest path arg
	"array=s"	=> \$arrayn		# array name
);

if ($out_path =~ $arrayn){
	# print useage help
	print "Useage: incl.pl -incl <filename> -array <arrayname>";
}else{
	$arrayn =~ s/\.c/.h/i;
	print "Adding \"include $arrayn\" -> $out_path ... ";
	open(OUT, ">>$out_path") or die;			# add to header file
	print OUT "#include \"$arrayn\"\n";
	close(OUT);
	print "complete!\n";
} # end script

