The Gerber files in this directory are for the FFPGMR11 project.

This device serves as a serial to bootloader bridge for programming and managing
68HC711 MCU devices.  The PCB is, as yet, untested.  Thus is issued this fair
warning: This design may or may not blow up in your face...

Most prototyping houses can process the files as-is.  The file list is as follows:

PCB2.apr		aperature file (not needed)
PCB2.DRL		binary drill file (generally not used)
PCB2.DRR		drill report file, contains drill tool sizes
PCB2.GBL		bottom copper layer
PCB2.GBS		bottom soldermask
PCB2.GTL		top copper layer
PCB2.GTO		top silk screen (component legend)
PCB2.GTS		top soldermask
PCB2.REP		gerber report file (generally not used)
PCB2.TXT		NC Drill (text)
PCB_readme.txt		(this file)

All layers have a board outline, so there is not a separate outline file.
0.062" FR-4 is suitable for this design, but 0.031" FR-4 is easier to separate and
use as a sub-module.  Generally, 0.031" fabs will cost more since most shops offer
a discounted service using 0.062" material.

The design is arranged as five separable circuit elements that together perform
the bootloader bridge funtion.  In order to complete that function, however,
there are several interconnects that must be added as jumper wires.  Consult the
schematic for details.  The number of interconnects is relatively low, on the order
of a dozen or so.  Each planned interconnect point has a dedicated SMD pad to accept
a wire end for soldering.

The four circuit elements are:
1) Power supply, +5V.  This is a +5V simple switcher that can accept up to 40Vin(dc).
	The same regulator is available in an HV version and can accept up to 60Vin(dc).
	An SMD coaxial power connector (center positive) or a 3 pin, 0.1" Molex header
	may be used to connect to a power source.

2) Power supply, +5V/12V.  This is a dual supply providing +5V and +12.25V outputs.
	It also includes switching circuits for the two supplies to allow on/off control
	from the project processor.

3) Processor.  This is an SiLabs C8051F34B processor with SMD component locations
	for a crystal and 3.3V regulator.  Available I/O pins are brought out to
	solder pads to ease the addition of jumper wires.  A 32K SRAM interface is
	also included along with some prototyping pads.

	Buyer beware: the programming port for the processor is a non-standard 6 pin
	connector.  An adapter is needed to allow the SiLabs programming tool to connect
	to this board.

4) RS-232 Interface.  This is a small section that contains a DB-9 connector and a
	MAX3232 RS-232 transceiver.

5) DB-25 Connector.  This is a PCB section that holds a DB-25 connector and pad-per-pin
	breakouts for all pins.

The circuit sections can be severed and soldered onto another prototyping substrate
to allow them to be used in other projects (the result is that the sections are "SCAB"-ed
on to the substrate..."SCAB" = Supplimental Circuit Addition Board).  This is done by
soldering the "mounting holes" to pads or copper planes on the receiving substrate. 
There are only a couple of routing traces on the bottom side (near the SRAM) and these
should be covered with kapton tape before attaching.  All other bottom surface copper
is ground plane or bare FR-4.  Alternately, the sections can be epoxied to the substrate
using a suitable epoxy formula.

Joe Haas
joeh@rollanet.org
KE0FF
12-07-2013
