/********************************************************************
 ********** COPYRIGHT (c) 2013 by Joe Haas DBA FF Systems   *********
 *
 *  File name: serial.h
 *
 *  Module:    Control
 *
 *  Summary:   This is the header file for serial I/O.
 *
 *******************************************************************/


/********************************************************************
 *  File scope declarations revision history:
 *    10-23-13 jmh:  creation date
 *
 *******************************************************************/

//------------------------------------------------------------------------------
// extern defines
//------------------------------------------------------------------------------

#define	BOOT_RESP_VOID	0
#define BOOT_RESP_TO	1
#define	BOOT_RESP_ER	2
#define	BOOT_RESP_OK	4
#define	BOOT_RESP_EPERR	5
#define	BOOT_RESP_RAERR	6

//------------------------------------------------------------------------------
// public Function Prototypes
//------------------------------------------------------------------------------

char boot_start(void);
char boot_send(U8* fnptr, U16 fnlen, U16 slen);
char hc11_waitok(U8 amatch, U16 toval);
char wait_targ(U8 resp);
