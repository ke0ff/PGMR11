/********************************************************************
 ********** COPYRIGHT (c) 2013 by Joe Haas DBA FF Systems   *********
 *
 *  File name: version.h
 *
 *  Module:    Control
 *
 *  Summary:   This header contains the software version number
 *             as a character string.
 *
 *******************************************************************/


/********************************************************************
 *  File scope declarations revision history:
 *    10-23-13 jmh:  creation date
 *
 *******************************************************************/

#ifdef VERSOURCE
S8    code version_number[] = "1.0";
S8    code date_code[]      = "16-Dec-2013";
#endif

//-----------------------------------------------------------------------------
// Public Fn Declarations
//-----------------------------------------------------------------------------
void dispSWvers(void);

#define VERSION_INCLUDED
