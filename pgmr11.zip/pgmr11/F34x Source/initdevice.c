/////////////////////////////////////
//  Generated Initialization File  //
/////////////////////////////////////

#include "C8051F340.h"

// Peripheral specific initialization functions,
// Called from the Init_Device() function
void Timer_Init()
{
    TCON      = 0x40;
    TMOD      = 0x20;
    CKCON     = 0x0C;
    TH1       = 0x98;
    TMR2CN    = 0x04;
    TMR2RLL   = 0x30;
    TMR2RLH   = 0xF8;
}

void UART_Init()
{
    SCON0     = 0x10;
    SBRLH1    = 0xFA;
    SCON1     = 0x10;
    SMOD1     = 0x0D;
    SBCON1    = 0x43;
}

void EMI_Init()
{
    EMI0CF    = 0x17;
}

void Port_IO_Init()
{
    // P0.0  -  Skipped,     Push-Pull,  Digital
    // P0.1  -  Skipped,     Push-Pull,  Digital
    // P0.2  -  TX1 (UART1), Open-Drain, Digital
    // P0.3  -  RX1 (UART1), Open-Drain, Digital
    // P0.4  -  TX0 (UART0), Push-Pull,  Digital
    // P0.5  -  RX0 (UART0), Open-Drain, Digital
    // P0.6  -  Skipped,     Open-Drain, Analog
    // P0.7  -  Skipped,     Open-Drain, Analog

    // P1.0  -  Unassigned,  Push-Pull,  Digital
    // P1.1  -  Unassigned,  Push-Pull,  Digital
    // P1.2  -  Unassigned,  Push-Pull,  Digital
    // P1.3  -  Unassigned,  Push-Pull,  Digital
    // P1.4  -  Unassigned,  Push-Pull,  Digital
    // P1.5  -  Unassigned,  Push-Pull,  Digital
    // P1.6  -  Skipped,     Push-Pull,  Digital
    // P1.7  -  Skipped,     Push-Pull,  Digital

    // P2.0  -  Skipped,     Push-Pull,  Digital
    // P2.1  -  Skipped,     Push-Pull,  Digital
    // P2.2  -  Skipped,     Push-Pull,  Digital
    // P2.3  -  Skipped,     Push-Pull,  Digital
    // P2.4  -  Skipped,     Push-Pull,  Digital
    // P2.5  -  Skipped,     Push-Pull,  Digital
    // P2.6  -  Skipped,     Push-Pull,  Digital
    // P2.7  -  Skipped,     Push-Pull,  Digital

    // P3.0  -  Skipped,     Push-Pull,  Digital
    // P3.1  -  Skipped,     Push-Pull,  Digital
    // P3.2  -  Skipped,     Push-Pull,  Digital
    // P3.3  -  Skipped,     Push-Pull,  Digital
    // P3.4  -  Skipped,     Push-Pull,  Digital
    // P3.5  -  Skipped,     Push-Pull,  Digital
    // P3.6  -  Skipped,     Push-Pull,  Digital
    // P3.7  -  Skipped,     Push-Pull,  Digital

    P0MDIN    = 0x3F;
    P0MDOUT   = 0x13;
    P1MDOUT   = 0xFF;
    P2MDOUT   = 0xFF;
    P3MDOUT   = 0xFF;
    P4MDOUT   = 0xFF;
    P0SKIP    = 0xC3;
    P1SKIP    = 0xC0;
    P2SKIP    = 0xFF;
    P3SKIP    = 0xFF;
    XBR0      = 0x01;
    XBR1      = 0x40;
    XBR2      = 0x01;
}

void Oscillator_Init()
{
    int i = 0;
    OSCXCN    = 0x67;
    for (i = 0; i < 3000; i++);  // Wait 1ms for initialization
    while ((OSCXCN & 0x80) == 0);
    CLKMUL    = 0x80;
    for (i = 0; i < 20; i++);    // Wait 5us for initialization
    CLKMUL    |= 0xC0;
    while ((CLKMUL & 0x20) == 0);
    CLKSEL    = 0x22;
    OSCICN    = 0x83;
}

void Interrupts_Init()
{
    IP        = 0x10;
    EIE2      = 0x02;
    IE        = 0xB0;
}

// Initialization function for device,
// Call Init_Device() from your main program
void Init_Device(void)
{
    Timer_Init();
    UART_Init();
    EMI_Init();
    Port_IO_Init();
    Oscillator_Init();
    Interrupts_Init();
}
