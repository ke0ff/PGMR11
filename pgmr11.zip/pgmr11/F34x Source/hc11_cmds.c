/********************************************************************
 ********* COPYRIGHT (c) 2013 by Joe Haas DBA FF Systems.   *********
 *
 *  File name: hc11_cmds.c
 *
 *  Module:    Control
 *
 *  Summary:
 *  HC11 boot command interface
 *  
 *******************************************************************/

#include <string.h>
#include <stdio.h>
#include <ctype.h>
#include <math.h>
#include <intrins.h>
#include <c8051F340.h>					// Device-specific SFR Definitions
#include "typedef.h"
#include "init.h"						// App-specific SFR Definitions

#include "cmd_fn.h"						// fn protos, bit defines, rtn codes, etc.
#include "serial.h"
#include "srec.h"
#include "hc11_cmds.h"					// hc11 fn headers
#include "hc11_fns.h"					// hc11 fn headers
#include "srec.h"					// hc11 fn headers

//=============================================================================
// local defines

// Processor I/O assignments
//P0
//sbit TXD0_P    = P0^4;                        // out: RS-232 tx data
sbit	txd_targ	= P0^3;

//P1
sbit	rst_targ	= P1^5;

//P2

//P3

//P4

#define HC11_TIMEOUT MS50

//=============================================================================
// local Fn protos
void reset_11(void);

//=============================================================================
// Fn routines
//=============================================================================

//=============================================================================
// wait_targ() looks for an $ff from target
//=============================================================================
char wait_targ(U8 resp){
	char	stat = FALSE;
	char	c;

	hc11_timer = SEC50MS;		// wait 50ms for response
	while((hc11_timer != 0) && !gotchar1());
	if(hc11_timer != 0){
		c = getchar1();			// got response, see if valid
		if(c == resp){
			stat = TRUE;		// response valid,
		}
	}
	return stat;
}

//=============================================================================
// boot_start() resets hc11 and sends start byte
//=============================================================================
char boot_start(void){
	char	stat = FALSE;
	U8		i = 3;					// three tries to get response from target

/*	do{
		rst_targ = 1;				// activate reset
		hc11_timer = SEC10MS;
		while(hc11_timer != 0);		// clean rx buffer & wait for timer
		rst_targ = 0;				// release reset
		hc11_timer = SEC10MS;
		while(hc11_timer != 0);		// clean rx buffer & wait for timer
		putchar1(0xff);				// if response valid, send download cmd to target
		hc11_timer = SEC10MS;
		while(hc11_timer != 0);		// clean rx buffer & wait for timer
	}while(bchar != ESC); */

	do{
		reset_11();					// reset target
		stat = wait_targ(0x00);		// look for response
		if(stat){
			i = 0;					// end the loop
			putchar1(0xff);			// if response valid, send download cmd to target
		}
	}while(i--);
	return stat;
}

//=============================================================================
// boot_send() sends hc11 function array via UART1 and returns.
//	accepts string ptr along with fnlen & slen.  If fnlen == blen, stop
//	sending when buffer is sent, else make sure slen # bytes sent
//	(pad remainder with zeros).
//	match receive data with send data using a pair of counters & pointers
//=============================================================================
char boot_send(U8* fnptr, U16 fnlen, U16 slen){

	U8*		vptr = fnptr;			// vfy pointer
	U8*		sptr = fnptr;			// send pointer
	U16		vcount = 0;				// vfy counter
	U16		scount = 0;				// send count
	char	done = BOOT_RESP_VOID;	// status flags
	U8		c;

	if(slen == 0) return 0x08;			// device not valid abort code
	while(gotchar1()) getchar1();		// pre-clean rx buffer
	hc11_timer = SEC50MS;				// pre-start timeout
	putchar1(*sptr++);					// send 1st buffer data & update pointer
	scount++;							// update send count
	do{
		if(gotchar1()){					// look for rcv'd data...
			hc11_timer = SEC50MS;		// restart timeout for every rcv'd char
			c = getchar1();				// get rcv'd chr
			gas_gage(0);				// execute gas guage
			if(vcount < fnlen){			// if still inside buffer,
				if(c != *vptr++){		// see if rcv'd data == buffer data
					done |= BOOT_RESP_ER;			// no, error
				}
			}else{
				if(c != 0){				// if outside buffer, rcv'd data should be 0
					done |= BOOT_RESP_ER;			// error if not
				}
			}
			if(++vcount == slen) done |= BOOT_RESP_OK;	// if done verifying, set exit
			if(scount < fnlen){				// if inside buffer,
				putchar1(*sptr++);			// send buffer data & update pointer
				scount++;					// update send count
			}else{
				if(scount < slen){			// if outside buffer,
					putchar1(0);			// send 0's/ff's
					scount++;				// update send count
				}
			}
		}
		if(hc11_timer == 0){			// if timeout, set error
			done |= BOOT_RESP_TO;
		}
	}while(done == BOOT_RESP_VOID);
	return done;
}

//=============================================================================
// reset_11() issues a reset pulse to the HC11 target
//=============================================================================
void reset_11(void){
	
	rst_targ = 1;				// activate reset
	hc11_timer = SEC50MS;
	while(hc11_timer != 0) getchar1();	// clean rx buffer & wait for timer
	rst_targ = 0;				// release reset
}

//=============================================================================
// hc11_waitok() waits for an OK response from target
//	amatch specifies match mode:
//	00 => FF 00 00 returns (4) (OK)
//	01 => returns 1st byte of okstr[]
//	02 => returns 2nd byte of okstr[]
//	03 => returns 3rd byte of okstr[]
//	04 => xx 10 3F returns (4) (OK)
//	else, return (2)
//	timeout returns (1)
//	toval sets timeout limit in ms
//=============================================================================
char hc11_waitok(U8 amatch, U16 toval){
#define	OKLEN 3
	U8		i = 0;
	char	done;
	U8		c;
static	U8	okstr[OKLEN];
	U8		match_H;
	U8		match_L;

	if(amatch == 1) return okstr[0];				// return resp data
	if(amatch == 2) return okstr[1];				// return resp addr_H
	if(amatch == 3) return okstr[2];				// return resp addr_L
	if(amatch == 5){
		okstr[0] = 0x01;							// set response to null (01 01 01 is not a normal response sequence)
		okstr[1] = 0x01;
		okstr[2] = 0x01;
		return BOOT_RESP_OK;
	}
	if(amatch == 4){
		match_H = 0x10;								// match config addr
		match_L = 0x3f;								// match config addr
	}else{
		match_H = 0x00;								// match no addr
		match_L = 0x00;								// match no addr
	}
	done = BOOT_RESP_VOID;							// pre-clear response
	do{
		hc11_timer = toval;							// set timeout limit
		while((hc11_timer != 0) && !gotchar1());	// troll for response or timeout
		if(hc11_timer == 0){
			done |= BOOT_RESP_TO;					// set timeout error
		}else{
			c = getchar1();							// get response
			okstr[i++] = c;							// fill response buffer
			if(i == OKLEN){
				done = 0x80;						// break loop;
			}
		}
	}while(!done);
	if(done != BOOT_RESP_TO){
		done = BOOT_RESP_ER;						// pre-set response error
		if((okstr[1] == match_H) && (okstr[2] == match_L)){
			if(match_L == 0x3f){
				done = BOOT_RESP_OK;				// only need to match addr for config
			}else{
				if(okstr[0] == 0xff){
					done = BOOT_RESP_OK;			// must match addr & data for others
				}
			}
		}
	}
	return done;
}
