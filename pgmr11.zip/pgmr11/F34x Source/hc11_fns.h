/********************************************************************
 ********** COPYRIGHT (c) 2013 by Joe Haas DBA FF Systems   *********
 *
 *  File name: hc11_fns.h
 *
 *  Module:    Control
 *
 *  Summary:   This is the header file for hc11 command fn externs.
 *
 *******************************************************************/


/********************************************************************
 *  File scope declarations revision history:
 *    11-16-13 jmh:  creation date
 *
 *******************************************************************/

//------------------------------------------------------------------------------
// extern defines
//------------------------------------------------------------------------------

extern code U8 eprog[];
U8 eprog_len(void);
#define eprog_dlen 107
extern code U8 config[];
U8 config_len(void);
#define config_dlen 83
extern code U8 configrd[];
U8 configrd_len(void);
#define configrd_dlen 29
extern code U8 eebulk[];
U8 eebulk_len(void);
#define eebulk_dlen 87
extern code U8 blank[];
U8 blank_len(void);
#define blank_dlen 72
extern code U8 eeprog[];
U8 eeprog_len(void);
#define eeprog_dlen 82
extern code U8 upload[];
U8 upload_len(void);
#define upload_dlen 75
extern code U8 devtyp[];
U8 devtyp_len(void);
#define devtyp_dlen 97
extern code U8 secho[];
U8 secho_len(void);
#define secho_dlen 43
