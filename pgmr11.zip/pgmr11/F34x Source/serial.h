/********************************************************************
 ********** COPYRIGHT (c) 2013 by Joe Haas DBA FF Systems   *********
 *
 *  File name: serial.h
 *
 *  Module:    Control
 *
 *  Summary:   This is the header file for serial I/O.
 *
 *******************************************************************/


/********************************************************************
 *  File scope declarations revision history:
 *    10-23-13 jmh:  creation date
 *
 *******************************************************************/

//------------------------------------------------------------------------------
// extern defines
//------------------------------------------------------------------------------

#define AKN		0x06
#define NAK		0x15
#define SOH		0x01
#define	EOT		0x04
#define CAN		0x18
#define ESC		27
#define XON		0x11
#define XOFF	0x13
#define	myEOF	26

#define TI1		0x02					// SCON1 bitmaps
#define	RI1		0x01

// xmodem defines
#define	XPOLY	0x1021					// xmodem polynomial (the CRC default)

// RX state commands
#define	RX_STATE_PROC	0x00			// state command to process state
#define	RX_STATE_INIT	0x20			// state command to set initialization state & init vars
#define	RX_STATE_PACK	0x21			// state command to terminate reception
#define	RX_STATE_CLEAR	0x22			// state command to clear xmode
#define	RX_STATE_QERY	0x23			// state command to querry data ready
// RX status responses
#define	XMOD_NULL		0x00			// nothing to report
#define	XMOD_DR			0x01			// xmodem data buffer ready
#define	XMOD_ABORT		0x7f			// xmodem error (aborted)
#define	XMOD_PKAK		0x02			// packet ack processed, seek next packet
#define	XMOD_ERR		0x03			// transmitter done sending (CAN)
#define	XMOD_DONE		0x04			// transmitter done sending
// TX state commands
#define	TX_STATE_PROC	0x00			// cmd to process TX data
#define	TX_STATE_INIT	0x20			// cmd to start a TX session
#define	TX_STATE_CLEAR	0x22			// cmd to do IPL
#define	TX_STATE_LAST	0x21			// cmd to signal end of tx

// Timer and retry limits
#define	XM_TO			(3*ONESEC)		// 3 seconds for xmodem timeout
#define ACKTRIES		10				// # tries to do start of packet before abort
										// this gives 30 sec to start an xmodem transfer in CRC before
										// SW reverts to checksum

//------------------------------------------------------------------------------
// public Function Prototypes
//------------------------------------------------------------------------------

char process_xrx(U8 state_cmd);
char process_xtx(char dc, U8 state_cmd);
void initserial(void);
char putchar(char c);
char putdch(char c);
char getchr(void);
char gotchr(void);
int putss(const char *string);
U8 putchar1(U8 c);
U8 getstat1(U8 cmd);
char gotchar1(void);
U8 getchar1(void);
char getch00(void);
//char xmode_off(void);
U16 calcrc(char c, U16 oldcrc, U16 poly);
char is_xmode(void);
char putchar_b(char c);
void enable_uart1(void);
void disable_uart1(void);
char set_baud(U16 baud);
