/********************************************************************
 ********* COPYRIGHT (c) 2013 by Joe Haas DBA FF Systems.   *********
 *
 *  File name: main.c
 *
 *  Module:    Control
 *
 *  Summary:
 *  This is the main code file for the FF-PGMR11 Protocol Converter.
 *  This device accepts .hex or .S19 data to program the 68HC711E9/E20/811E2
 *  devices using the 68HC711E9PGMR board.  Provision is also extended to
 *  support the 68HC711D3 and other "E" derivatives using their respective
 *  PGMR boards.
 *
 *  The CCA consists of a C8051F34C processor, power supply (5V, 12V, and 3.3V),
 *  PC serial connection, and a DSUB25 (male) connector which is designed to
 *  mate with the PGMR boards.  The protocol converter CCA accepts 9 to 40VDC
 *  input power via either a 3 pin Molex connector or a coaxial power connector.
 *  It produces 5V using a buck-switcher, 3.3V using an LDO linear regulator,
 *  and 12.25V (HC11 Vpp) using a boost switcher (5V to 12.25V).
 *
 *	Alternately, the hardware may consist of an F340-DK with a daughter card
 *	for the SRAM and a PGMRE9 (or equivalent) providing the 5V and 12.25V
 *	power supplies.
 *
 *  The PC serial connection runs at 115.2 Kbaud and supports XON/XOFF
 *  handshaking for data transfers.  The F34C/340 uses the EMIF to interface a
 *  32K SRAM that is used to hold the DUT object data.  This is sufficient
 *  memory to capture the EPROM image for most of the HC711 "E" derivatives.
 *
 *  Project scope declarations revision history:
 *    10-23-13 jmh:  creation date
 *
 *******************************************************************/


/********************************************************************
 *  File scope declarations revision history:
 *    10-23-13 jmh:  creation date
 *
 *******************************************************************/

//-----------------------------------------------------------------------------
// main.c
//  Uses a C8051F34C processor (or equiv.) to provide a 2 port UART system
//  to perform HC11 EPROM programming protocols.  System controls the DUT
//  power supplies and downloads boot mode data using UART1 at 7812 baud.
//  UART0 is used for user interface and data download at 115,200 baud
//	(with xon/xoff handshaking).  Autobaud detection is implemented for the
//	host: Enter a CR (ascii 0x0D) at reset at either 57.6kb, 38.4kb, 19.2kb,
//	or 9.6kb to reset the system to the host baud rate. Once accepted, or
//	once a valid command is issued at 115.2kb, the baud rate is frozen until
//	the next system reset.
//
//  PGMR11 module is modified to utilize unused DB25 pins for the following:
//      * +5V
//      * +12.25Vpp
//      * DEV[2:0]: a 3 bit personality code to allow autodetect of the
//        DUT type.
//
//  CLI is simple with the following core commands:
//      * DEvice interrogate/set Response is device type.
//        Params are: "E2" (HC811E2), "E20","E32", "E9", and "D3"
//      * Blank check EPROM/EEPROM
//      * Config program/read (does bulk EEPROM erase if pgm)
//      * PGM - program device EPROM/EEPROM
//      * Verify EPROM/EEPROM
//		* BUlk EEPROM erase
//      * COpy device data into RAM
//      * Upload object data to RAM (XON/XOFF or xmodem)
//      * Download RAM to host (XON/XOFF or xmodem)
//      * TEST1: download a simple test program to the DUT
//        Runs out of RAM and echos back inverted serial rcv data.
//        Host ESC aborts.
//      * TEST2: Test converter by testing external RAM.
//		* Fill/check pgmr ext RAM contents.
//		* pgmr Mem r/w
//		* CHecksum: performs checksum or crcsum on contents of pgmr RAM
//		  within the bounds of the current device start/end addresses.
//		  option to set begining sum, poly val, and store sum to pgmr
//		  RAM location.
//		* PGMR software VERSion querry.
//		* S0 bcmd parse: utility to produce S0 command lines that can be
//		  embedded into an Srecord file to control the PGMR during data
//		  upload.
//		* addr Offset (for S-record uploads from host).  Adds a fixed offset
//		  to all upload data destinations.
//
//  Interrupt Resource Map:
//      Timer0 is reserved (INT 1)
//      Timer1 is reserved (INT 3)
//      Timer2 int provides application timers (INT 5)
//      Timer3 is reserved (INT 14)
//      UART0 is host serial port (INT 4)
//      UART1 is target serial port (INT 16)
//      SMBUS is reserved (INT 7)
//      USB is reserved (INT 8)
//
//  I/O Resource Map:
//      P0: UART I/O
//      P1: digital I/O controls
//      P2: A[15:8] (EMIF)
//      P3: A[7:0] (EMIF)
//      P4: D[7:0] (EMIF)
//
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Includes
//-----------------------------------------------------------------------------
// compile defines

#define MAIN_C
#include <stdio.h>
#include <string.h>
#include "init.h"
#include "typedef.h"
#include "C8051F340.H"
#include "version.h"
#include "serial.h"
#include "cmd_fn.h"

//-----------------------------------------------------------------------------
// Definitions
//-----------------------------------------------------------------------------

//  see init.h for main #defines
#define	MAX_REBUF	4		// max # of rebufs
#define	GETS_INIT	0xff	// gets_tab() static initializer signal

//-----------------------------------------------------------------------------
// Local Variables
//-----------------------------------------------------------------------------

// Processor I/O assignments
//P0
sbit	txd1	    = P0^2;			// out: target rx data
sbit	rxd1	    = P0^3;			// in:  target tx data

//P1
sbit	rst_targ	= P1^5;			// out: targ reset
sbit	vpp_on	 	= P1^4;			// out: vpp pwr on (act low)
sbit	vdd_on	 	= P1^3;			// out: vdd pwr on (act low)
sbit	err_led 	= P1^2;			// out: err led (act hi)
sbit	ok_led	 	= P1^1;			// out: OK led (act hi)

//P2

//P3

//P4

U16	abaud = 0;						// 0 = 115.2kb (the default)
//-----------------------------------------------------------------------------
// Local variables in this file
//-----------------------------------------------------------------------------

U16 app_timer1ms;					// app timer
U16  waittimer;						// gp wait timer
U16  ledtimer; 						// led blink timer
U16 xm_timer;						// xmodem timer
U16 hc11_timer;						// hc11 timer
S8 handshake;						// xon/xoff enable
S8 xoffsent;						// xoff sent
char bchar;
S8	err_led_stat;					// err led status

//-----------------------------------------------------------------------------
// Local Prototypes
//-----------------------------------------------------------------------------

void Timer_Init(void);
void wait(U16 waitms);
void Timer_SUBR(void);
char *gets_tab(char *buf, char *save_buf[3], int n);

//-----------------------------------------------------------------------------
// main()
//  The main function runs a forever loop in which the main application operates.
//	Performs system initialization, boot status announcement, and main polling loop.
//	Polling loop calls CLI capture/parce fns.
//	Also maintains and processes re-do buffers (4 total) that are accessed by the
//	TAB key.  Allows the last 4 valid command lines to be recalled and executed
//	(after TAB'ing to desired recall command, press ENTER to execute, or ESC to
//	clear command line).
//	Autobaud rate reset allows user to select alternate baudarates after reset:
//		115,200 baud is default.  A CR entered after reset at 57600, 38400,
//		19200, or 9600 baud will reset the system baud rate and prompt for user
//		acceptance.  If accepted, baud rate is frozen.  If rejected, baud rate
//		returns to 115200.  The first valid command at 115200 will also freeze
//		the baud rate.  Once frozen, the baud rate can not be changed until
//		system is reset.
//-----------------------------------------------------------------------------
void main(void)
{
    char	xdata buf[80];			// command line buffer
    char	xdata rebuf0[80];		// re-do buffer#1
    char	xdata rebuf1[80];		// re-do buffer#2
    char	xdata rebuf2[80];		// re-do buffer#3
    char	xdata rebuf3[80];		// re-do buffer#4
	char	got_cmd = FALSE;		// first valid cmd flag (freezes baud rate)
    U8		argn;					// number of args
    char*	cmd_string;				// CLI processing ptr
    char*	args[ARG_MAX];			// ptr array into CLI args
	char*	rebufN[] = {rebuf0, rebuf1, rebuf2, rebuf3}; // pointer array to re-do buffers
	U8		rebuf_num = 0;			// current re-buf selection
	U16		offset = 0;				// srecord offset register
	U16		cur_baud = 0;			// current baud rate

    
    // start of main
    PCA0MD = 0x00;                  // disable watchdog

    // init MCU system
    Init_Device();                  // init MCU
	dut_pwr(TARGET_INIT);			// init target power I/O
	P2 = 0x7f;						// default A15 = 0, all others = 1 or float
	P3 = 0xff;
	P4 = 0xff;
	EMI0CN = 0x80;					// set bank reg at bottom of ext RAM

	// init vars
	err_led_stat = LED_ON;			// set err led to on
	do_green_led(LED_ON);			// green led = on

	// init system
	initserial();					// init serial regs

	// init status LED
	process_xrx(RX_STATE_CLEAR);	// init xmodem receive
	EA = 1;							// enable ints
	wait(20);						// a bit of delay..
	dispSWvers(); 					// display reset banner
	rebuf0[0] = '\0';				// init cmd re-do buffers to empty
	rebuf1[0] = '\0';
	rebuf2[0] = '\0';
	rebuf3[0] = '\0';
	bcmd_resp_init();				// init bcmd response buffer
	wait(20);						// a bit more delay..
	rst_targ = 0;					// release target reset
	while(gotchr()) getchr();		// clear serial input in case there was some POR garbage
	dev_sel(NO_DEVICE);				// init target device to "no device"
	err_led_stat = LED_OFF;			// set err led to off
	do_green_led(LED_OFF);			// green LED off
	gets_tab(buf, rebufN, GETS_INIT); // initialize gets_tab()
	// main loop
	while(1){
		putchar_b(XON);
		*args[1] = '\0';
		putss("pmgr11>");									// prompt
		cmd_string = gets_tab(buf, rebufN, 80); 			// get cmd line & save to re-do buf
		if(!got_cmd){										// if no valid commands since reset, look for baud rate change
			if(cur_baud != abaud){							// abaud is signal from gets_tab() that indicates a baud rate change
				if(set_baud(abaud)){						// try to set new baud rate
					puts("");								// move to new line
					dispSWvers();							// display reset banner & prompt to AKN new baud rate
					while(gotchr()) getchr();				// clear out don't care characters
					putss("press <Enter> to accept baud rate change: ");
					while(!gotchr());						// wait for user input
					puts("");								// move to new line
					if(getchr() == '\r'){					// if input = CR
						cur_baud = abaud;					// update current baud = new baud
						got_cmd = TRUE;						// freeze baud rate
					}else{
						set_baud(0);						// input was not a CR, return to default baud rate
						cur_baud = abaud = 0;
					}
				}else{
					abaud = cur_baud;						// new baud rate not valid, ignore & keep old rate
				}
			}else{
				got_cmd = TRUE;								// freeze baud rate (@115.2kb)
			}
		}
		argn = parse_args(cmd_string,&args);				// parse cmd line
		if(x_cmdfn(argn, &args, &offset)) got_cmd = TRUE;	// process cmd line, set got_cmd if cmd valid
	}
}  // end main()

//-----------------------------------------------------------------------------
// Subroutines
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// gets_tab puts serial input into buffer, UART0.
//-----------------------------------------------------------------------------
// Main loop for command line input.
// waits for a chr and puts into buf.  If 1st chr = \t, copy re-do buf into
//  cmdbuf and cycle to next re-do buf.  if more than n chrs input, nul term buf,
//	disp "line too long", and return.  if \n or \r, copy buf to save_buf & return
//  returns buf (pointer).
//	if n == 0xff, initialize statics and exit.
//
//	11/08/13: Modified to support 4 (MAX_REBUF) rolling cmd save buffers
//	11/15/13: Modified to support auto-baud detect on CR input
//		For the following, each bit chr shown is one bit time at 115200 baud (8.68056us).
//			s = start bit (0), p = stop bit (1), x = incorrect stop, i = idle (1), bits are ordered  lsb -> msb:
//	 the ascii code for CR = 10110000
//			At 115.2kb, CR = s10110000p = 0x0D
//
//			At 57.6 kb, CR = 00110011110000000011 (1/2 115.2kb)
//			@115.2, this is: s01100111ps00000001i = 0xE6, 0x80
//
//			At 38.4 kb, CR = 000111000111111000000000000111 (1/3 115.2kb)
//			@115.2, this is: s00111000p11111s00000000xxxiii = 0x1c, 0x00
//
//			At 19.2 kb, CR = 000000111111000000111111111111000000000000000000000000111111 (1/6 115.2kb)
//			@115.2, this is: s00000111piis00000111piiiiiiiis00000000xxxxxxxxxxxxxxxiiiiii = 0xE0, 0xE0, 0x00
//
//			At 9600 b,  CR = 000000000000111111111111000000000000111111111111111111111111000000000000000000000000000000000000000000000000111111111111 (1/12 115.2kb)
//			@115.2, this is: s00000000xxxiiiiiiiiiiiis00000000xxxiiiiiiiiiiiiiiiiiiiiiiiis00000000xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxiiiiiiiiiiii = 0x00, 0x00, 0x00
//
//		Thus, @ 57.6 kb, a CR = 0xE6 followed by 0x80
//			  @ 38.4 kb, a CR = 0x1C followed by 0x00
//			  @ 19.2 kb, a CR = 0xE0 followed by 0xE0 (plus a 0x00)
//			  @ 9600 b, a  CR = 0x00 followed by 0x00 (plus a 0x00)
//
//		NOTE: gets_tab is only used for command line input and thus should not
//		see non-ascii data under normal circumstances.

char *gets_tab(char *buf, char *save_buf[], int n)
{
	char	*cp;
	char	*sp;
	char	c;
	int		i = 0;
	static	U8   rebuf_num;
	static	U8	 last_chr;

	if((rebuf_num > (MAX_REBUF - 1)) || (n == GETS_INIT)){ // n == 0xff is static initializer signal
		rebuf_num = 0;									// init recall buffer pointer
		last_chr = 0xff;								// init to 0xff (not a valid baud select identifier chr)
		return buf;										// skip rest of Fn
	}
    cp = buf;
    sp = save_buf[rebuf_num];
    do{
        c = getch00();
        switch(c){
			case 0xE0:									// look for 19.2kb autoselect
				if(last_chr == 0xE0){
					abaud = 19200;
					c = '\r';
				}
				break;

			case 0x00:									// look for 38.4kb or 9600b autoselect
				if(last_chr == 0x1C){
					abaud = 38400;
					c = '\r';
				}else{
					if(last_chr == 0x00){
						abaud = 9600;
						c = '\r';
					}
				}
				break;

			case 0x80:									// look for 57.6kb autoselect
				if(last_chr == 0xE6){
					abaud = 57600;
					c = '\r';
				}
				break;

            case '\t':
				if(i != 0){								// if tab, cycle through saved cmd buffers
					do{
						i--;							// update count/point
						cp--;
						if((*cp >= ' ') && (*cp <= '~')){
							putchar('\b');				// erase last chr if it was printable
							putchar(' ');
							putchar('\b');
						}
					}while(i != 0);
					cp = buf;							// just in case we got out of synch
				}
				//copy saved string up to first nul, \n, or \r
				if(--rebuf_num == 0xff){
					rebuf_num = MAX_REBUF - 1;
				}
				sp = save_buf[rebuf_num];
				while((*sp != '\0') && (*sp != '\r') && (*sp != '\n')){
					putdch(*sp);
					*cp++ = *sp++;
					i++;
				}
                break;

            case '\b':
                if(i != 0){								// if bs & not start of line,
                    i--;								// update count/point
                    cp--;
                    if((*cp >= ' ') && (*cp <= '~')){
                        putchar('\b');					// erase last chr if it was printable
                        putchar(' ');
                        putchar('\b');
                    }
                }
                break;

            case '\r':									// if cr, nul term buf & exit
            case '\n':									// if nl, nul term buf & exit
                i++;
                *cp++ = c;
                break;

            case ESC:									// if esc, nul buf & exit
                cp = buf;
                c = '\r';								// set escape condition
				i = 0;
                break;

            default:
                i++;
                *cp++ = c;								// put chr in buf
                putdch(c);								// no cntl chrs here
                break;
        }
		last_chr = c;									// set last chr
    } while((c != '\r') && (c != '\n') && (i < n));		// loop until c/r or l/f or buffer full
	if(i >= n){
		puts("!! buffer overflow !!");
		*buf = '\0';									// abort line
	}else{
		puts("");										// echo end of line to screen
		*cp = '\0';										// terminate command line
		if((*buf >= ' ') && (*buf <= '~')){				// if new buf not empty (ie, 1st chr = printable),
			strncpy(save_buf[rebuf_num], buf, n);		// copy new buf to save
			if(++rebuf_num >= MAX_REBUF) rebuf_num = 0;
		}
	}
    return buf;
}

//-----------------------------------------------------------------------------
// wait() uses a dedicated ms timer to establish a defined delay (+/- 1LSB latency)
//-----------------------------------------------------------------------------
void wait(U16 waitms)
{

    waittimer = waitms;
    while(waittimer != 0);
}

//-----------------------------------------------------------------------------
// dut_pwr() if pwron == TARGET_ON, dut power on; if pwron == TARGET_OFF,
//	DUT == instant off (no delay)
//	else NOP.  Always return pwr status.
//	OFF: Disables UART1 (so that the I/O pins can be set to 0) and turns off the power
//	control pins for Vdd and Vpp.
//	ON: enables UART1 and sets the Vdd and Vpp I/O pins to ON.
//	A 50ms delay is performed after each action except for the TARGET_INIT option
//	which is intended for initial power on intiialization.
//-----------------------------------------------------------------------------
char dut_pwr(U8 pwron){

	char c = FALSE;

	switch(pwron){
		case TARGET_OFF:
			disable_uart1();				// disable uart so we can set i/o pins = 0
			txd1 = 0;						// set target MCU pins to 0 to kill sneak paths
			rxd1 = 0;
			vpp_on = 0;						// turn off vpp 1st
			wait(SEC50MS);
			vdd_on = 0;						// then vdd
			wait(SEC50MS);
			break;

		case TARGET_ON:
			rxd1 = 1;
			txd1 = 1;
			enable_uart1();					// re-enable uart
			wait(SEC50MS);
			vdd_on = 1;						// turn on vdd 1st
			wait(SEC50MS);
			vpp_on = 1;						// then vpp
			wait(SEC50MS);
			break;

		case TARGET_INIT:
			disable_uart1();				// disable uart so we can set i/o pins = 0
			txd1 = 0;						// instant off for POR
			rxd1 = 0;						// turn off I/O to MCU
			vpp_on = 0;						// turn off vpp
			vdd_on = 0;						// & vdd
			break;

		default:
			break;
	}
	if(vdd_on == 1) c = TRUE;
	return c;
}

//-----------------------------------------------------------------------------
// do_green_led() processes green status LED
//-----------------------------------------------------------------------------
void do_green_led(U8 led_cmd){

	switch(led_cmd){
		case LED_OFF:
			ok_led = 0;		// led off
			break;

		case LED_ON:
			ok_led = 1;		// led on
			break;
	}
}

//-----------------------------------------------------------------------------
// do_red_led() processes red status LED (allows external Fns to control LED)
//-----------------------------------------------------------------------------
void do_red_led(U8 led_cmd){
	
	err_led_stat = led_cmd;
}

//-----------------------------------------------------------------------------
// Timer2_ISR
//-----------------------------------------------------------------------------
//
// Called when timer 2 overflows (NORM mode):
//	intended to update app timers @ 1ms per lsb
//
//-----------------------------------------------------------------------------

void Timer2_ISR(void) interrupt 5
{
static U16 prescale;

    TF2H = 0;						// Clear Timer2 interrupt flag
    if(++prescale > 500){			// 1000ms per sec
		switch(err_led_stat){
			case LED_OFF:
				err_led = 0;		// led off
				err_led_stat = 0xff;
				break;

			case LED_ON:
				err_led = 1;		// led on
				err_led_stat = 0xff;
				break;

			case LED_BLINK:
				err_led = ~err_led;	// led toggle
				break;
		}
        prescale = 0;
    }
    if (app_timer1ms != 0){         // update app timer
        app_timer1ms--;
    }
    if (waittimer != 0){            // update wait timer
        waittimer--;
    }
    if (ledtimer != 0){             // update led timer
        ledtimer--;
    }
    if (xm_timer != 0){         	// update xmodem timer
        xm_timer--;
    }
    if (hc11_timer != 0){         	// update hc11 timer
        hc11_timer--;
    }
}
//-----------------------------------------------------------------------------
// End Of File
//-----------------------------------------------------------------------------
