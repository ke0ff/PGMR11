/********************************************************************
 ********** COPYRIGHT (c) 2013 by Joe Haas DBA FF Systems   *********
 *
 *  File name: typedef.h
 *
 *  Module:    Control
 *
 *  Summary:   This header contains the variable declaration definitions
 *       used by all modules of the system.
 *
 *
 *******************************************************************/

/********************************************************************
 *  File scope declarations revision history:
 *    10-23-13 jmh:  creation date
 *
 *******************************************************************/

/* shorthand type definitions */

#define U8                 unsigned char
#define S8                 signed char
#define U16                unsigned int
#define S16                signed int
#define U32                unsigned long
#define S32                signed long
#define F32                float
#define F64                double
#define BOOL               unsigned char

#define TRUE               1
#define FALSE              !TRUE

#define TYPEDEF_INCLUDED
