/********************************************************************
 ********** COPYRIGHT (c) 2013 by Joe Haas DBA FF Systems   *********
 *
 *  File name: init.h
 *
 *  Module:    Control
 *
 *  Summary:   defines and global declarations for main.c
 *
 *******************************************************************/

#include "typedef.h"

#ifndef INIT_H
#define INIT_H
#endif

//-----------------------------------------------------------------------------
// Global Constants
//-----------------------------------------------------------------------------

#define TARGET_ON	0x01		// dut_pwr() param defines
#define TARGET_OFF	0x00
#define TARGET_INIT	0x02
#define TARGET_STAT 0xff

#define	LED_OFF		0x00		// LED commands
#define	LED_ON		0x01
#define	LED_BLINK	0x02
#define	LED_NOP		0xff

//#define EXTXTAL           	// un-comment if external xtal is used

#ifdef EXTXTAL
#define XTAL 1
#else
#define XTAL 0
#endif

#define OSC_LF 4            	// osc clock selects
#define OSC_HF 0
#define OSC_EXT 1

#define SEC10MS    10           // timer constants (ms)
#define SEC50MS    50           // timer constants (ms)
#define SEC75MS    74
#define SEC100MS  100
#define SEC250MS  250
#define SEC500MS  500
#define SEC750MS  750
#define SEC1     1000
#define ONESEC   SEC1
#define SEC2     2000
#define SEC3     3000
#define SEC5     5000
#define SEC10   10000
#define SEC15   15000
#define SEC30   30000
#define SEC60   60000
#define SEC300 300000L
#define	ONEMIN	(SEC60 * 60)

// timer definitions.  Uses EXTXTAL #def to select between ext crystal and int osc
//  for normal mode.
// SYSCLK value in Hz
#define SYSCLKL 10000L
#ifdef EXTXTAL
#define SYSCLK 18432900L
#else
#define SYSCLK (12000000L)
#endif
// timer2 register value
#define TMR2RLL_VAL (U8)((65536 -(SYSCLK/(12L * 1000L))) & 0xff)
#define TMR2RLH_VAL (U8)((65536 -(SYSCLK/(12L * 1000L))) >> 8)


//-----------------------------------------------------------------------------
// Global variables
//-----------------------------------------------------------------------------

#ifndef MAIN_C
extern U16 app_timer1ms;		// app timer
extern U16 xm_timer;			// xmodem timer
extern U16 hc11_timer;			// hc11 timer
extern char bchar;				// global bchar storage
extern S8 handshake;			// xon/xoff enable
extern S8 xoffsent;				// xoff sent
#endif

//-----------------------------------------------------------------------------
// main.c Fn prototypes
//-----------------------------------------------------------------------------

void Init_Device(void);
void process_blink(U16 blink_on, U16 blink_rate);
char dut_pwr(U8 pwron);
void do_green_led(U8 led_cmd);
void do_red_led(U8 led_cmd);

//-----------------------------------------------------------------------------
// End Of File
//-----------------------------------------------------------------------------
