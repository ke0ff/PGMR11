/********************************************************************
 ********* COPYRIGHT (c) 2013 by Joe Haas DBA FF Systems.   *********
 *
 *  File name: cmd_fn.c
 *
 *  Module:    Control
 *
 *  Summary:
 *  CLI Command Interpreter
 *  
 *******************************************************************/

#include <string.h>
#include <stdio.h>
#include <ctype.h>
#include <math.h>
#include <intrins.h>
#include <c8051F340.h>					// Device-specific SFR Definitions
#include "typedef.h"
#include "init.h"						// App-specific SFR Definitions

#include "cmd_fn.h"						// fn protos, bit defines, rtn codes, etc.
#include "serial.h"
#include "srec.h"
#include "version.h"
#include "hc11_cmds.h"
#include "hc11_fns.h"

//=============================================================================
// local registers

U16	device_eprom_start;					// device parameter regs
U16	device_eprom_end;
U16	device_eeprom_start;
U16	device_eeprom_end;
S8	device_eprom;
S8	device_eeprom;
U8	device_type;
S8	boot_len_fixed;
U16	device_max_bootlen;
U16	device_pprog;
char device_valid;
#define MAX_PRESP_BUF 80
char bcmd_resp_buf[MAX_PRESP_BUF + 10];
char* bcmd_resp_ptr;

// enum error message ID
enum err_enum{	no_response, no_device, target_timeout };

// enum list of command numerics
//	each enum corresponds to a command from the above list (lastcmd corresponds
//	with the last entry, 0xff)
enum cmd_enum{	device,copy,upl,checks,config_c,bulk_c,blank_c,pgm,downl,tst1,tst2,
				s0parse,offset_c,fill,mem_wr,help1,help2,vers,verify,lastcmd,helpcmd };

#define	cmd_type	char	// define as char for list < 255, else define as int

//=============================================================================
// local Fn declarations

U8 get_Dargs(U8 argsrt, U8 nargs, char* args[ARG_MAX], U16 params[ARG_MAX]);
cmd_type cmd_srch(char* string);
char parm_srch(U8 nargs, char* args[ARG_MAX], char* parm_str);
U8 get_dev_id(U8 nargs, char* args[]);
void puts_bcmd(char* string);
void dev_mem_error(char eprom_select);
void dev_itg(char* obuf);
void disp_error(U8 errnum);
void disp_fail(char* buf, char* s, U16 c, U16 d);
void disp_wait_addr(char* buf);
U16 boot_se(U8* bptr, U16 start, U16 end, U16 ppaddr);
U8* log_error_byte(U8* lbuf, U8 d, U8 h, U16 a);
void disp_error_log(U8* lbuf, U16 len);
void do_help(void);
char ram_range(U16 start, U16 end);
void ram_range_err(void);
char do_blank(U8 nargs, char* args[], U16 params[], char eprom_select, char* obuf, char verbose);
void do_offs(U8 nargs, char* args[], U16 params[], U16* offset);
char do_cmd_help(U8 cmd_id);
char do_pgm(U8 nargs, char* args[], U16 params[], char eprom_select, char* obuf, char verbose, U16* i0);
char do_vfy(U8 nargs, char* args[], U16 params[], char eprom_select, char* obuf, char verbose, U16* i1, U16* i2);
char do_chks(U8 nargs, char* args[], U16 params[], char eprom_select, char* obuf, char verbose, U16* i0);
char do_config(U8 nargs, char* args[], U16 params[], char eprom_select, char* obuf, char verbose);
char do_bulk(char eprom_select, char* obuf, char verbose);
char fill_ram(U8 nargs, char* args[], U16 params[]);
char check_ram(U8 nargs, char* args[], U16 params[]);

//=============================================================================
// CLI cmd processor entry point
//	Uses number of args (nargs) and arg pointer array (args[]) to lookup
//	command and execute.
//	offset is srecord offset value which is maintianed in main() and passed
//	forward to srecord functions (upload)
//=============================================================================

int x_cmdfn(U8 nargs, char* args[ARG_MAX], U16* offset){

#define	OBUF_LEN 110				// buffer length
#define	MAX_LOG_ERRS (OBUF_LEN / 4)	// max number of errors logged by verify cmd
	char	obuf[OBUF_LEN];			// gp output buffer
	U16		params[ARG_MAX];		// holding array for numeric params
	char	c;						// char temp
	char	d;						// char temp
	char	pv = FALSE;				// verify option select flag (set if "V" found in args)
	char	pw = FALSE;				// operator wait select flag (set if "W" found in args)
	char	px = FALSE;				// xmodem select flag (set if "X" found in args)
	int		cmd_found = TRUE;		// default to true, set to false if no valid cmd identified
	char*	s;						// char temp pointer
	char*	t;						// char temp pointer
	char	cmd_id;					// command enumerated id
	char	eprom_select = FALSE;	// prom select param detect flag (TRUE if "EPROM" found in args, defaults to EEPROM)
	U8		i;						// temp
	U8		j;						// temp
	U8*		ptr0;					// U8 mem pointer
	U8*		ptr1;					// U8 mem pointer#2
	U16		i0;						// U16 param temps
	U16		i1;
	U16		i2;

	bchar = '\0';																// clear global escape
    if (nargs > 0){
		for(i = 0; i <= nargs; i++){											//upcase all args
			s = args[i];
			str_toupper(s);
		}
		t = args[0];															// point to first arg (cmd)
		cmd_id = cmd_srch(t);													// search for command
		s = args[1];															// point to 2nd arg (1st param)
		if(*s == '?'){
			if((cmd_id == help1) || (cmd_id == help2)){
				do_help();														// set to list all cmd helps
				puts("");
				for(i = 0; i < lastcmd; i++){
					if(do_cmd_help(i)) puts("");
				}
			}else{
				do_cmd_help(cmd_id);											// do help for cmd only
			}
		}else{
			c = parm_srch(nargs, args, "V");									// capture verify floater
			if(c){
				pv = TRUE;
				nargs--;
			}
			c = parm_srch(nargs, args, "W");									// capture wait floater
			if(c){
				pw = TRUE;
				nargs--;
			}
			c = parm_srch(nargs, args, "X");									// capture xmodem select floater
			if(c){
				px = TRUE;
				nargs--;
			}
			c = parm_srch(nargs, args, "EPROM");								// capture EPROM select floater
			if(c){
				eprom_select = TRUE;
				nargs--;
			}
			c = parm_srch(nargs, args, "EEPROM");								// capture EEPROM select floater
			if(c){
				eprom_select = FALSE;
				nargs--;
			}
			gas_gage(2);														// init gas gauge to disabled state
			switch(cmd_id){														// dispatch command
				case help1:
				case help2:														// MAIN HELP
					do_help();
					break;

				case downl:														// DOWNLOAD CMD
					if(eprom_select){											// set start and stop address limits
						params[0] = device_eprom_start;							// if EPROM
						params[1] = device_eprom_end;
					}else{
						params[0] = device_eeprom_start;						// if EEPROM
						params[1] = device_eeprom_end;
					}
					get_Dargs(1, nargs, args, &params);							// parse param numerics into params[] array
					if((params[0] < RAM_START) && (params[1] < RAM_START)){
						disp_error(no_device);
					}else{
						if(px){													// if xmodem:
							puts("xmodem pgmr->host");							// cmd akn display
							process_xtx(0, TX_STATE_INIT);						// init xmodem xfr engine
							process_stx(params[0], params[1]);					// send srecords
							do{													// close xrecord
								c = process_xtx(0x00, TX_STATE_LAST);
							}while((c != XMOD_DONE) && (c != XMOD_ERR) && (c != XMOD_ABORT));
						}else{													// if ascii xfr:
							puts("ascii pgmr->host");							// cmd akn display
							if(pw){
								puts("press enter or ESC:");					// wait enabled, prompt to continue...
								do{
									c = getchr();
								}while(!c);
							}else c = '\0';
							if(c != ESC){
								process_stx(params[0], params[1]);				// send srecords
							}
						}
					}
					break;
						
				case device:													// DEVICE CMD
					switch(*s){
						default:
							i = NO_DEVICE;										// default selection
							c = parm_srch(nargs, args, "E9");					// process HC711E9 device select
							if(c){
								i = 9;
							}else{
								c = parm_srch(nargs, args, "LE20");				// process HC711E20 device, low segment
								if(c){
									i = 19;
								}else{
									c = parm_srch(nargs, args, "E20");			// process HC711E20 device, hi segment
									if(c){
										i = 20;
									}else{
										c = parm_srch(nargs, args, "E32");		// process HC711E32 device select
										if(c){
											i = 32;
										}else{
											c = parm_srch(nargs, args, "E2");	// process HC811E2 device select
											if(c){
												i = 2;
											}else{
												c = parm_srch(nargs, args, "D3"); // process HC711D3 device select
												if(c){
													i = 3;
												}
											}
										}
									}
								}
							}
							dev_sel(i);											// set device-specific variables
							// no break (fall through to interrogate)
						case '\0':
							dev_itg(obuf);										// display device setting
							if(boot_start()){									// querry device for type data
								j = devtyp_len();
								for(i = 0; i < j; i++){
									obuf[i] = devtyp[i];						// xfr hc11 code to local buffer
								}
								t = obuf + ((U16)j & 0xff);						// calc end of buffer pointer
								i1 = boot_se(t, params[0], params[1], device_pprog); // add start/stop addrs
								i1 += (U16)j & 0xff;							// calc xfr length
								i2 = 256;										// for itg, this is fixed at 256
								c = boot_send(obuf, i1, i2);					// (target code accounts for over-max xfers)
								if(c == BOOT_RESP_OK){							// if xfer OK, look for response
									i1 = 0;										// init response length to zero
									hc11_timer = SEC50MS;						// set timeout timer
									ptr0 = obuf - 1;							// pre-decrement ptr to get the loop to trap-out correctly
									do{
										if(gotchar1()){
											d = getchar1();						// get rcvd chr,
											*++ptr0 = d;						// put in buffer,
											i1++;								// update chr count,
											hc11_timer = SEC50MS;				// reset timeout..
										}
									}while((i1 != 10) && (hc11_timer != 0));
									if(hc11_timer == 0) disp_error(target_timeout); //timeout error
								}
								if(c == BOOT_RESP_OK){							// response OK, format for display
									i0 = (U16)obuf[0] & 0xff;
									i1 = ((U16)obuf[1] << 8) | ((U16)obuf[2] & 0xff);
									i2 = ((U16)obuf[3] << 8) | ((U16)obuf[4] & 0xff);
									params[0] = (U16)obuf[5] & 0xff;
									params[1] = ((U16)obuf[6] << 8) | ((U16)obuf[7] & 0xff);
									params[2] = ((U16)obuf[8] << 8) | ((U16)obuf[9] & 0xff);
									puts("ROM bytes from DUT:");
									sprintf(obuf,"$BFD1: $%02x $%04x $%04x",i0, i1, i2);
									puts(obuf);
									sprintf(obuf,"$BFBB: $%02x $%04x $%04x",params[0], params[1], params[2]);
									puts(obuf);
								}else{
									disp_fail(obuf, "DevTyp", c, d);			// target code fail
								}
							}else{
								disp_error(no_response);						// device not responding fail
							}
							break;
					}
					do_red_led(LED_OFF);										// clear error LED
					break;

				case blank_c:													// BLANK chk CMD
					if(device_valid){											// if device valid
						do_blank(nargs, args, params, eprom_select, obuf, TRUE);
					}else{
						disp_error(no_device);									// display err, no device selected
					}
					break;

				case checks:													// CHECKSUM CMD
					// CHecksum cmd:  CH S/C/? POLY INITIAL BEGIN_ADDR END_ADDR STOR_ADDR
					//				defaults: 0x1021   0     devstart   $ffff     $0
					// ? prints help string, S for addition sum, C for CRC
					// defaults are either empty or "-"
					do_chks(nargs, args, params, eprom_select, obuf, TRUE, &i0);
					break;

				case bulk_c:													// BULK EEPROM ERASE CMD
					// BUlk erase cmd:  BU ?/
					//					issues bulk erase cmd to target, no options
					if(device_valid){
						do_bulk(eprom_select, obuf, TRUE);
					}else{
						disp_error(no_device);									// display err, device
					}
					break;

				case config_c:													// CONFIG SET/ITG CMD
					// COnfig cmd:  CO ?/REG_BITS
					//				If no REG_BITS, reads current value
					if(device_valid){
						c = do_config(nargs, args, params, eprom_select, obuf, TRUE);
						if((c == BOOT_RESP_OK) || (c == BOOT_RESP_VOID)){
							if(boot_start()){									// interrogate...
								i1 = i2 = configrd_len();						// get target code length
								if(boot_len_fixed) i2 = device_max_bootlen;		// update length
								c = boot_send(configrd, i1, i2);				// send target code
								d = BOOT_RESP_VOID;								// pre-clear response
								if(c == BOOT_RESP_OK) d = hc11_waitok(4, SEC50MS); // if code send OK, wait for response
								if((d != BOOT_RESP_OK) || (c != BOOT_RESP_OK)){
									disp_fail(obuf, "CONFIG Read", c, d);		// fail msg
								}else{
									j = hc11_waitok(1, 0);						// get config value
									sprintf(obuf,"CONFIG reg: %02x",(U16)j & 0xff); // display config value
									puts(obuf);
								}
							}else{
								disp_error(no_response);						// display err, no target response
							}
						}
					}else{
						disp_error(no_device);									// display err, no device selected
					}
					break;

				case copy:														// COPY CMD
					// COPy cmd:  COP ?/EPROM/START/END
					//			  copies target mem to pgmr,
					if(device_valid){
						if(eprom_select){										// set the param defaults
							params[0] = device_eprom_start;						// EPROM
							params[1] = device_eprom_end;
							c = device_eprom;
						}else{
							params[0] = device_eeprom_start;					// EEPROM
							params[1] = device_eeprom_end;
							c = device_eeprom;
						}
						if(!c){
							dev_mem_error(eprom_select);						// dev doesn't have this resource
						}else{
							get_Dargs(1, nargs, args, &params);					// parse param numerics
							if(!ram_range(params[0], params[1])){
								ram_range_err();
							}else{
								sprintf(obuf,"parms: %04x, %04x",params[0],params[1]);
								puts(obuf);
								i2 = params[3];
								ptr0 = dut_xdata + params[0] - RAM_START;		// set start/running ptr
								ptr1 = dut_xdata + params[1] - RAM_START;		// set end ptr
								gas_gage(params[1] - params[0]);				// set gas gage
								if(boot_start()){
									j = upload_len();							// calc cmd code len
									for(i = 0; i < j; i++){
										obuf[i] = upload[i];					// xfr hc11 code to local buffer
									}
									t = obuf + ((U16)j & 0xff);					// calc buffer end ptr
									i1 = boot_se(t, params[0], params[1], device_pprog); // add start/stop addrs
									i1 += (U16)j & 0xff;						// calc actual xfr len
									i2 = i1;
									if(boot_len_fixed) i2 = device_max_bootlen;
									c = boot_send(obuf, i1, i2);				// xfr code to target
									if(c == BOOT_RESP_OK){						// if XFR OK,
										i1 = 0;									// clear byte counter
										hc11_timer = SEC50MS;					// set timeout timer
										ptr0--;									// pre-decrement to get the loop to trap-out correctly
										do{
											if(gotchar1()){						// if target chr ready:
												gas_gage(0);					// update gas-gauge,
												c = getchar1();					// get targ chr
												*++ptr0 = c;					// store to buffer & update ptr
												i1++;							// update byte count
												hc11_timer = SEC50MS;			// reset timeout
											}
										}while((ptr0 != ptr1) && (hc11_timer != 0));
										puts("");
										if(hc11_timer == 0) disp_error(target_timeout); // display err, timeout
										sprintf(obuf,"%u bytes",i1);			// display byte count
										puts(obuf);
									}
								}
							}
						}
					}else{
						disp_error(no_device);									// display err, no device selected
					}
					break;

				case vers:														// SW VERSION CMD
					dispSWvers();
					break;

				case verify:													// VERIFY CMD
					// Verify cmd:  Verify dev->pgmr ?/EPROM/START/END
					//			  compares target with pgmr,
					if(device_valid){
						c = do_vfy(nargs, args, params, eprom_select, obuf, TRUE, &i1, &i2);
						if(c == BOOT_RESP_EPERR){
							dev_mem_error(eprom_select);						// start == end is fatal
						}else{
							puts("");
							if(c == BOOT_RESP_RAERR){
								ram_range_err();
							}else{
								if(c == BOOT_RESP_TO){
									disp_error(target_timeout);					// display err, timeout
								}else{
									if(i1 != 0){								// display err banner and log
										if(i1 > MAX_LOG_ERRS){
											i0 = MAX_LOG_ERRS;
										}else{
											i0 = i1;
										}
										puts("Verify fail: "); 					// put up err tally
										disp_error_log(obuf, i0);
										sprintf(obuf,"errs: %u, ",i1);
										putss(obuf);
									}else{
										putss("Verify complete, ");				// verify done, OK
									}
									sprintf(obuf,"bytes: %u",i2);				// put upp byte tally
									puts(obuf);
								}
							}
						}	
					}else{
						disp_error(no_device);									// display err, no device selected
					}
					break;

				case upl:														// UPLOAD CMD
					if(*s == 'R'){												// if 1st param is "R",
						puts("Upload Response:");								// display last bcmd responses (if any)
						puts(bcmd_resp_buf);
					}else{
						exec_bcmd("z",obuf, offset);							// init bcmd processor
						bcmd_resp_ptr = bcmd_resp_buf;							// init bcmd response buffer
						*bcmd_resp_ptr = '\0';
						if(pv){													// process verify modifier
							j = PD_VRFY;
							putss("Verify");
							exec_bcmd("x",obuf, offset);						// disable bcmd processor
						}else{													// not verify, do transfer
							j = PD_STOR;
							putss("Send");
						}
						if(px){													// xmodem xfr prompt...
							puts(" xmodem host->pgmr. Waiting for xmodem start...");
							process_xrx(RX_STATE_INIT);							// init xmodem rcv
							process_srx(j, obuf, offset);						// ascii srecord receive
							do{
								i = process_xrx(RX_STATE_PROC);
								if(i == XMOD_DR) process_xrx(RX_STATE_PACK);
							}while((i != XMOD_DONE) && (i != XMOD_ABORT) && (i != XMOD_ERR));
							process_xrx(RX_STATE_CLEAR);						// close xmodem xfr
						}else{
							puts(" ascii host->pgmr. Waiting for Srecs...");
							handshake = TRUE;
							process_srx(j, obuf, offset);						// ascii srecord receive
							handshake = FALSE;
						}
						hc11_timer = SEC500MS;
						while(hc11_timer);
						putss("\nUpload ");
						if(process_data(0, 0, PD_QERY) != PD_OK){
							i0 = ((U16)process_data(0, 0, PD_QERYH) << 8) | ((U16)process_data(0, 0, PD_QERYL) & 0xff);
							sprintf(obuf,"fail, addr: %04x",i0);
							puts(obuf);
						}else{
							puts("OK.");
						}
						if(bcmd_resp_ptr != bcmd_resp_buf){
							puts("Response:");									// display bcmd responses (if any)
							puts(bcmd_resp_buf);
						}
					}
					break;

				case tst1:
					// TEST1
					bchar = '\0';
					if(device_valid){
						puts("targ serial tx test ...");
						if(boot_start()){
							gas_gage(16384);									// set gas gage
							j = secho_len();
							for(i = 0; i < j; i++){
								obuf[i] = secho[i];								// xfr hc11 code to local buffer
							}
							t = obuf + ((U16)j & 0xff);
							i1 = boot_se(t, params[0], params[1], device_pprog); // add start/stop addrs
							i1 += (U16)j & 0xff;
							i2 = i1;
							if(boot_len_fixed) i2 = device_max_bootlen;
							c = boot_send(obuf, i1, i2);
							if(c == BOOT_RESP_OK){
								hc11_timer = SEC50MS;
								while(hc11_timer != 0);							// timeout the bootloader
								i0 = 0;
								hc11_timer = SEC50MS;							// wait 50ms for response
								i = 0x01;
								do{
									putchar1(i);
									while((hc11_timer != 0) && !gotchar1());
									if(gotchar1()){
										j = getchar1();
										j = ~j;
										if(j != i){
											sprintf(obuf,"err: %02x",(U16)c & 0xff);
											puts(obuf);
										}
										i++;
										i0++;
										gas_gage(0);							// process gas guage
										if(i0 == 16384){
											puts(" 16384 chrs...");
											gas_gage(16384);					// set gas gage
											i0 = 0;
										}
										hc11_timer = SEC50MS;					// wait 50ms for response
									}
								}while((bchar != ESC) && (hc11_timer != 0));
								if((hc11_timer == 0) && (bchar != ESC)) disp_error(target_timeout); //puts("timeout");
								sprintf(obuf,"\n%u bytes",i0);
								puts(obuf);
							}
						}
					}else{
						disp_error(no_device);									// err, no device selected
					}
					break;

				case tst2:
					// TEST2
					if(ram_pattern_pass()){
						puts("PGMR RAM test pass");
					}else{
						puts("PGMR RAM test FAIL");
					}
					break;

				case pgm:														// PGM CMD
					// PGM cmd:  PGM dev->pgmr ?/EPROM/START/END
					//			  sends pgmr data to target for programming,
					if(device_valid){
						c = do_pgm(nargs, args, params, eprom_select, obuf, TRUE, &i0);
						if(c == BOOT_RESP_EPERR){
							dev_mem_error(eprom_select);						// start == end is fatal
						}else{
							puts("");
							if(c == BOOT_RESP_RAERR){
								ram_range_err();
							}else{
								if(c == BOOT_RESP_TO){
									disp_error(target_timeout);					// display err, timeout
									c = getstat1(0);
								}else{
									if(c == BOOT_RESP_ER){
										puts("PGM errors:");					// display err, 
									}else{
										puts("PGM complete");					// display OK 
									}
									sprintf(obuf,"%u bytes",i0);				// display byte count
									puts(obuf);
								}
							}
						}
					}else{
						disp_error(no_device);									// err, no device selected
					}
					break;

				case offset_c:													// OFFSET CMD (future)
					// "O" sets object load offset
					do_offs(nargs, args, params, offset);
					sprintf(obuf,"Srecord addr offset = $%04x",*offset);		// display offset value
					puts(obuf);
					break;

				case s0parse:													// S0 PARSE UTILITY CMD
					// "S0" processes params and outputs S0 records that contain the params.
					//	Used by operator to construct embedded command records that can be
					//	inserted into object file to perform automated pgm of combined
					//	EPROM/EEPROM files.
					//		NOTE: Only Fill, Pgm, Verify, Dev, and Offset are supported by
					//		the embeded command interpreter
					if(*s == 'U'){
						puts("s0un-parse: reserved");							// s0 un-parse, future
						puts("bcmd disp. util...ascii host->pgmr. Waiting for Srecs...");
						handshake = TRUE;
						process_srx(PD_QEMBED, obuf, offset);					// ascii srecord receive, only display bcmds
						handshake = FALSE;
					}else{
						nargs = parse_args(s, args);
						t = args[nargs-1];
						while(*t++ != '\0');									// find end of parm list (end of last param)
						*t++ = '\n';
						*t = '\0';												// terminate param
						s = t = args[0];
						puts(t);
						i = 2;													// include terminating '\n' and '\0'
						while(*t++ != '\n') i++;								// calc byte length of parm list
						if(i < (BCMD_BUFLEN + 1)){
							sprintf(obuf,"S0 cmd parse, %u bytes:", (U16)i);
							puts(obuf);
							put_sline((U8*)s, 0, i, 0);							// copy params to s0 rec
						}else{
							i0 = BCMD_BUFLEN - 3;
							sprintf(obuf,"S0 line too long! %u chrs max.", i0);
							puts(obuf);											// display err, line too long
						}
					}
					break;

				case fill:														// FILL HOST MEM CMD
					// does a fill or verify of external SRAM.  Addr range
					//	is fixed at 0x8000-0xffff
					if(pv){
						c = check_ram(nargs, args, params);						// is verify
						if(c){
							putss("Verify ");
						}	
					}else{
						c = fill_ram(nargs, args, params);						// is fill
					}
					if(c){
						sprintf(obuf,"Fill: mem = %02x, OK", (params[0] & 0xff));	// display result
						puts(obuf);
					}else{
						ram_range_err();
					}	
					break;

				case mem_wr:													// HOST MEM WR CMD
					// pgmr Mem write:  M ?/addr/data
					//				If no parms, reads current value
					params[0] = 0x0000;											// pre-set addr
					params[1] = 0xFF00;											// pre-set data invalid
					get_Dargs(1, nargs, args, &params);							// parse numerics
					ptr0 = dut_xdata + params[0] - RAM_START;					// set addr ptr
					if((params[1] < 0x100) && (params[0] >= RAM_START)){		// valid params detected, do write
						*ptr0 = (U8)params[1];
					}
					sprintf(obuf,"pgmr mem: %04x %02x",params[0], (U16)*ptr0 & 0xff);
					puts(obuf);
					break;

				default:
				case lastcmd:													// not valid cmd
					cmd_found = FALSE;
					break;
			}
		}
    }
	if(bchar == ESC) while(gotchr()) getchr();									// if ESC, clear CLI input chrs
	return cmd_found;
}

//=============================================================================
// do_help() displays main help screen
//=============================================================================
void do_help(void){

	puts("FF-PGMR11 CMD List:");
	puts("\tDEvice (dut) select\tdut Config reg");
	puts("\tUpload/vfy host->pgmr\tDownload pgmr->host");
	puts("\tCHecksum object\t\tCOpy dut->pgmr");			
	puts("\tBlank chk dut\t\tsrec rx Offset");
	puts("\tBUlk erase EEPROM\tTEST1 run dut test");
	puts("\tPGM dut\t\t\tTEST2 run pgmr test");
	puts("\tVerify dut\t\tS0 bcmd parse");
	puts("\tFill/vfy pgmr ram\tpgmr software VERSion\n");
	puts("Syntax: <cmd> <arg1> <arg2> ... args are optional depending on cmd.");
	puts("\t<arg> order is critical except for floaters.");
	puts("\"?\" as first <arg> gives cmd help, \"? ?\" lists all cmd help lines. When");
	puts("selectively entering <args>, use \"-\" for <args> that keep default value.");
	puts("\"=\" must precede decimal values w/o spaces. Floating <args>: these non-number");
	puts("<args> can appear anywhere in <arg> list: \"X\" = xmodem, \"W\" = wait for");
	puts("operator, \"EPROM\" = eprom opr (EEPROM opr is default), \"V\" = verify modifier.");
	puts("Note: XON/XOFF handshake required if ascii uploads are employed with bcmds.");
	puts("Supports baud rates of 115.2, 57.6, 38.4, 19.2, and 9.6 kb.  Press <Enter>");
	puts("as first character after reset at the desired baud rate.");
}

//=============================================================================
// do_cmd_help() displays individual cmd help using cmd_id enum
//=============================================================================
char do_cmd_help(U8 cmd_id){

	char c = TRUE;
	
	switch(cmd_id){													// dispatch help line
		case downl:														// DOWNLOAD CMD
			puts("Download pgmr->host: ?/X/W/EPROM");
			break;
				
		case device:													// DEVICE CMD
			puts("DEVice sel: ?/devid");
			puts("   Turns on DUT power (except NO DEVICE = power off) & Clears error LED.");
			puts("   68HC(7)11 devid: E2 (811), D3, E9, LE20, E20, E32, N (no dev).");
			puts("   E20 accesses 12K segment, LE20 accesses 8K segment.");
			puts("   Note: E9 selection will access E1, E2, and E9 parts.");
			break;

		case blank_c:													// BLANK chk CMD
			puts("Blank check DUT: ?/start/end/EPROM");
			break;

		case checks:													// CHECKSUM CMD
			puts("CHecksum: ?/S/C/start_addr/end_addr/stor_addr/initial/poly/EPROM");
			puts("   defaults:    DUTstart   DUTend  <no store>   0    $1021");
			puts("   S = checksum (16b, uses init), C = crc (16b, uses init & poly).");
			break;

		case bulk_c:													// BULK EEPROM ERASE CMD
			// BUlk erase cmd:  BU ?/
			//					issues bulk erase cmd to target, no options
			puts("BUlk erase DUT EEPROM: ?/");
			break;

		case config_c:													// CONFIG SET/ITG CMD
			// COnfig cmd:  CO ?/REG_BITS
			//				If no REG_BITS, reads current value
			puts("Config: ?/reg_bits");
			break;

		case copy:														// COPY CMD
			// COPy cmd:  COP ?/EPROM/START/END
			//			  copies target mem to pgmr,
			puts("COpy DUT->pgmr: ?/EPROM/start_addr/end_addr");
			break;

		case verify:													// VERIFY CMD
			// Verify cmd:  Verify dev->pgmr ?/EPROM/START/END
			//			  compares target with pgmr,
			puts("Verify DUT->pgmr: ?/EPROM/start_addr/end_addr");
			break;

		case upl:														// UPLOAD CMD
			puts("Upload host->pgmr: ?/Xmodem/Verify/Response");
			puts("   Response: re-disp last bcmd responses.");
			puts("   Processes S0 bcmds as they are encountered during upload.");
			puts("   A fail of the Blank bcmd disables bcmds remaining in upload.");
			break;

		case tst1:
			// TEST1
			puts("TEST1 (DUT test): ?/Ram/X (loads user RAM pgm from host)");
			break;

		case tst2:
			// TEST2
			puts("TEST2 (PGMR test): ?/ (pgmr ram test)");
			break;

		case pgm:														// PGM CMD
			// PGM cmd:  PGM dev->pgmr ?/EPROM/START/END
			//			  sends pgmr data to target for programming,
			puts("PGM pgmr->DUT: ?/EPROM/start_addr/end_addr");
			break;

		case offset_c:													// OFFSET CMD (future)
			// "O" sets object load offset
			puts("Offset: ?/offset value");
			puts("   Signed <offset value> added to Srecord address during upload.");
			puts("   range is $0000 to $FFFF (or +$7FFF to -$8000 if signed numbers).");
			break;

		case s0parse:													// S0 PARSE UTILITY CMD
			// "S0" processes params and outputs S0 records that contain the params.
			//	Used by operator to construct embedded command records that can be
			//	inserted into object file to perform automated pgm of combined
			//	EPROM/EEPROM files.
			//		NOTE: Only Fill, Pgm, Vfy, Dev, Blank, BUlk, CHks, Config, and Offset
			//		are supported by the UPload embedded command interpreter
			puts("S0 cmd parse util: ?/U/\"<bcmd> <args> .. <args>\" (45 chrs max, quoted)");
			puts("   Valid bcmds = Fill, Pgm, Vfy, Dev, Blank, BUlk, CHks, Config, or Offs.");
			puts("   This command parses batch cmds (bcmds) without any error checking.");
			puts("   \"U\" un-parse: do file upload (ascii only, data ignored), displays bcmds.");
			break;

		case fill:														// FILL HOST MEM CMD
			// does a fill or check of external SRAM.  Addr range
			//	is fixed at 0x8000-0xffff
			puts("Fill/vfy pgmr ram: ?/data/start_addr/end_addr/V");
			puts("   \'V\' <arg> to verify pgmr memory data instead of fill.");
			break;

		case mem_wr:													// HOST MEM WR CMD
			// pgmr Mem write:  M ?/addr/data
			//				If no parms, reads current value
			puts("pgmr Mem write: ?/addr/data");
			break;

		default:
			c = FALSE;
			break;
	}
	return c;
}
		
//=============================================================================
// disp_error() displays standard error messages & device off status
//=============================================================================
void disp_error(U8 errnum){

	do_red_led(LED_BLINK);
	switch(errnum){
		case no_response:
			puts("!! ERR !! No response from DUT.");
			break;

		case no_device:
			puts("!! ERR !! No DUT selected.");
			break;

		case target_timeout:
			puts("!! ERR !! DUT timeout.");
			break;

		default:
			break;
	}
	if(!dut_pwr(TARGET_STAT)) puts("DEVICE OFF");		// signal device off
}

//=============================================================================
// disp_fail() displays pgm/read error message with params
//	this is a debug function that displays the HC11 fn comms status
//	Also, this fn sets the status LED to blink to indicate a failure was encountered
//=============================================================================
void disp_fail(char* buf, char* s, U16 c, U16 d){

	do_red_led(LED_BLINK);
	sprintf(buf,"%s Failed!! errs: %02x %02x", s, (U16)c, (U16)d);
	puts(buf);
}

//=============================================================================
// disp_wait_addr() displays resp/addr from hc11_waitok
//=============================================================================
void disp_wait_addr(char* buf){

	U16	a;
	U16	b;
	U16	c;
	
	a = (U16)(hc11_waitok(2, 0)) & 0xff;
	b = (U16)(hc11_waitok(3, 0)) & 0xff;
	c = (U16)(hc11_waitok(1, 0)) & 0xff;
	sprintf(buf,"$%02x%02x: $%02x", a, b, c);
	puts(buf);
}

//=============================================================================
// exec_bcmd() processes in-line object commands for batch-style programming.
//	this is a mini version of x_cmdfn().
//	bcmdbuf_ptr is a pointer to the embeded cmd list.  This Fn Searches starting at
//	bcmdbuf_ptr for nulls and '\n': nulls define end of param (& start of
//	next param), '\n' defines end of input.
//	CMD is pointed to by pargs[0].
//	lower-case cmds can only be processed from inline code since all user input is
//	upcased before processing.  Thus, lower case cmds are for OS init and cleanup:
//	"z" cmd (lower case) initializes verr = FALSE.  do "exec_cmd("z",dummy,dummy)" to init.
//	"x" cmd (lower case) disables bcmds for verify (sets verr = TRUE). do "exec_cmd("x",dummy,dummy)"
//	blank check cmd disables bcmds if check fails
//	dummy is any appropriate reference (not needed for lower-case cmds).
//=============================================================================
void exec_bcmd(char* bcmdbuf_ptr, char* obuf, U16* offset){

#define	MAX_PARGS	8			// defines max# of args allowed for p-cmds (incl. cmd)

	static char null_str[] = "";
	static char verr;						// bcmd enable flag.  If blank chk err, don't process any more bcmds if TRUE
	U8		npargs = 0;						// arg count, start with no args
	U8		i;								// temp
	char	c;								// temp
	char	e = FALSE;						// eprom select
	U16		params[8];						// parsed numeric storage
	U16		i0;								// temp
	U16		i1;								// temp
	U16		i2;								// temp
	char*	s = bcmdbuf_ptr;				// init ptr to buffer start
	char*	t;								// temp ptr
	char*	pargs[MAX_PARGS];				// arg pointer array
	char	cbuf[20];						// sprint buffer
	
	if(*s == 'z'){
		verr = FALSE;											// init no verr (enable bcmds)
		return;													// and nothing else...
	}
	if(*s == 'x'){
		verr = TRUE;											// set to disable bcmds
		return;													// and nothing else...
	}
	if(!verr){
		pargs[0] = s;											// 1st arg points to buffer start
		do{
			if(*s == '\0'){										// look for next null chr in buffer
				npargs++;										// update arg count
				pargs[npargs] = s + 1;							// set argptr to start of next arg
			}
		}while(*s++ != '\n');									// until end of buffer
		i = npargs;
		while(i < MAX_PARGS) pargs[i++] = null_str;				// init remaining pointers
		t = pargs[0];											// get cmd chr
		if(parm_srch(npargs, pargs, "EPROM")){
			e = TRUE;											// is eprom modifier
			npargs--;
		}
		switch(*t){												// dispatch cmd
			case 'P':
				c = do_pgm(npargs, pargs, params, e, obuf, FALSE, &i0);	// process pgm
				if(c == BOOT_RESP_TO){
					puts_bcmd("TO\n");
				}else{
					if(c != BOOT_RESP_OK){
						puts_bcmd("PERR");						// display err, 
					}else{
						puts_bcmd("POK");						// display OK 
					}
					sprintf(cbuf," %u bytes\n",i0);				// display byte count
					puts_bcmd(cbuf);
				}
				break;

			case 'V':
				c = do_vfy(npargs, pargs, params, e, obuf, FALSE, &i1, &i2); // process vfy
				if(c == BOOT_RESP_TO){
					puts_bcmd("TO\n");
				}else{
					if(c != BOOT_RESP_OK){
						sprintf(cbuf,"VERR %u errs\n",i1);		// display err count
					}else{
						sprintf(cbuf,"VOK %u B\n",i2);			// display byte count
					}
					puts_bcmd(cbuf);
				}
				break;

			case 'B':
				if(*++t == 'U'){
					c = do_bulk(FALSE, obuf, FALSE);			// process bulk erase
					if(c != BOOT_RESP_OK){
						puts_bcmd("BeERR\n");					// display err, 
					}else{
						puts_bcmd("BeOK\n");
					}
				}else{
					c = do_blank(npargs, pargs, params, e, obuf, FALSE); // process blank chk
					if(c != BOOT_RESP_OK){
						puts_bcmd("BLERR...abort bcmds\n");		// display err, 
						verr = TRUE;							// set verify err, lockout future bcmds
					}else{
						puts_bcmd("BLOK\n");					// display OK
					}
				}
				break;

			case 'C':
				if(*++t == 'H'){
					c = do_chks(npargs, pargs, params, e, obuf, FALSE, &i0);
					if(c != BOOT_RESP_OK){
						puts_bcmd("ChERR\n");					// display err, 
					}else{
						sprintf(cbuf,"ChOK $%04x\n",i0);		// display chks
						puts_bcmd(cbuf);
					}
				}else{
					c = do_config(npargs, pargs, params, FALSE, obuf, FALSE);	// config
					if(c != BOOT_RESP_OK){
						puts_bcmd("CgERR\n");					// display err, 
					}else{
						puts_bcmd("CgOK\n");
					}
				}
				break;

			case 'D':
				i = get_dev_id(npargs, pargs);					// process dev sel
				if(i != 0){
					dev_sel(i);
					sprintf(cbuf,"D%u\n",(U16)i);
					puts_bcmd(cbuf);
				}else puts_bcmd("derr\n");
				break;

			case 'O':
				do_offs(npargs, pargs, params, offset);
				sprintf(cbuf,"a+$%04x",*offset);				// display offset value
				puts_bcmd(cbuf);
				break;

			case 'F':
				params[0] = 0xffff;
				get_Dargs(1, 2, pargs, params);
				if(params[0] > 0x7fff){
					params[0] = 0xff;							// default fill value
				}
				if(fill_ram(npargs, pargs, params)){			// fill pgmr SRAM
					puts_bcmd("f-OK\n");
				}else{
					puts_bcmd("f-ERR\n");
				}
				break;

			default:
				break;
		}
	}
}

//***********************//
// bcmd functions follow //
//***********************//

//=============================================================================
// pgm command, responds with BOOT_RESP_?? result
//=============================================================================
char do_pgm(U8 nargs, char* args[], U16 params[], char eprom_select, char* obuf, char verbose, U16* i0){

	char	c = BOOT_RESP_VOID;		// char temp
	char	d;						// char temp
	char*	t;						// char temp pointer
	U8		i;						// temp
	U8		j;						// temp
	U8*		ptr0;					// U8 mem pointer
	U8*		ptr1;					// U8 mem pointer#2
	U16		i1;
	U16		i2;

	if(eprom_select){											// set the param defaults
		params[0] = device_eprom_start;							// EPROM
		params[1] = device_eprom_end;
		d = device_eprom;
	}else{
		params[0] = device_eeprom_start;						// EEPROM
		params[1] = device_eeprom_end;
		d = device_eeprom;
	}
	if(!d){
		c = BOOT_RESP_EPERR;
	}else{
		get_Dargs(1, nargs, args, params);						// parse param numerics
		if(!ram_range(params[0], params[1])){					// s/e needs to be in RAM
			c = BOOT_RESP_RAERR;
		}else{
			if(verbose){
				sprintf(obuf,"start/end: %04x, %04x",params[0],params[1]);
				puts(obuf);
			}
			ptr0 = dut_xdata + params[0] - RAM_START;			// set start/running ptr
			ptr1 = dut_xdata + params[1] - RAM_START;			// set end ptr
			*i0 = params[1] - params[0] + 1;					// calculate length of data to pgm
			if(boot_start()){
				do_green_led(LED_ON);
				getstat1(0xff);									// clear serial errors
				if(eprom_select){								// set up cmd code xfr based on EPROM/EEPROM/device type
					j = eprog_len();							// EPROM
					t = eprog;
				}else{
					j = eeprog_len();							// EEPROM
					t = eeprog;
				}
				for(i = 0; i < j; i++){
					obuf[i] = *t++;								// xfr hc11 cmd code to local buffer
				}
				t = obuf + ((U16)j & 0xff);						// calc end of buffer ptr
				i1 = boot_se(t, params[0], params[1], device_pprog); // add start/stop addrs
				i1 += (U16)j & 0xff;							// calc xfr len
				i2 = i1;
				if(boot_len_fixed) i2 = device_max_bootlen;
				c = boot_send(obuf, i1, i2);
				t = obuf;										// use obuf for err log
				if(c == BOOT_RESP_OK){
					if(verbose) gas_gage(*i0 - 1);				// set gas gage
					wait_targ(0xff);							// wait for target ready
					c = boot_send(ptr0, *i0, *i0);				// send data
				}
				do_green_led(LED_OFF);
			}
		}
	}
	return c;
}

//=============================================================================
// vfy command, responds with BOOT_RESP_?? result
//=============================================================================
char do_vfy(U8 nargs, char* args[], U16 params[], char eprom_select, char* obuf, char verbose, U16* i1, U16* i2){

	char	c = BOOT_RESP_VOID;		// boot response status
	char	ch;						// temp
	char	d;						// temp
	char*	t;						// char temp pointer
	U8		i;						// temp
	U8		j;						// temp
	U8*		ptr0;					// U8 mem pointer
	U8*		ptr1;					// U8 mem pointer#2
	U16		i0;						// U16 param temps

	if(eprom_select){											// set the param defaults
		params[0] = device_eprom_start;							// EPROM
		params[1] = device_eprom_end;
		d = device_eprom;
	}else{
		params[0] = device_eeprom_start;						// EEPROM
		params[1] = device_eeprom_end;
		d = device_eeprom;
	}
	if(!d){
		c = BOOT_RESP_EPERR;
	}else{
		get_Dargs(1, nargs, args, params);						// parse param numerics
		if(verbose){
			sprintf(obuf,"start/end: %04x, %04x",params[0],params[1]);
			puts(obuf);
		}
		ptr0 = dut_xdata + params[0] - RAM_START;				// set start/running ptr
		ptr1 = dut_xdata + params[1] - RAM_START;				// set end ptr
		i0 = params[1] - params[0] + 1;							// calculate length of data to pgm
		if(boot_start()){
			getstat1(0xff);										// clear serial errors
			j = upload_len();									// upload does verify
			t = upload;
			for(i = 0; i < j; i++){
				obuf[i] = *t++;									// xfr hc11 cmd code to local buffer
			}
			t = obuf + ((U16)j & 0xff);							// calc end of buffer ptr
			*i1 = boot_se(t, params[0], params[1], device_pprog); // add start/stop addrs
			*i1 += (U16)j & 0xff;								// calc xfr len
			*i2 = *i1;
			if(boot_len_fixed) *i2 = device_max_bootlen;
			c = boot_send(obuf, *i1, *i2);
			t = obuf;											// use obuf for err log
			if(c == BOOT_RESP_OK){
				if(verbose) gas_gage(i0);						// set gas guage
				hc11_timer = SEC50MS;							// set timeout timer
				ptr0--;											// pre-decrement to get the loop to trap-out correctly
				*i1 = 0;										// clear err count
				*i2 = 0;										// clear byte count
				do{
					if(gotchar1()){								// if chr received:
						ch = getchar1();						// get target data,
						if(verbose) gas_gage(0);				// update gas guage,
						d = *++ptr0;							// get host data,
						(*i2)++;								// inc data counter,
						if(d != ch){							// if verify fails:
							if(verbose) gas_gage(1);			// set gas guage err status
							if(((*i1)++ < MAX_LOG_ERRS) && verbose){ // store err addr/data to err log until full
								i0 = (U16)ptr0;
								t = log_error_byte(t, ch, d, i0); // store err log entry
							}
						}
						hc11_timer = SEC50MS;					// reset timeout
					}
				}while((ptr0 != ptr1) && (hc11_timer != 0) && (bchar != ESC));
				if(hc11_timer == 0) c = BOOT_RESP_TO;
			}
		}
	}
	return c;
}

//=============================================================================
// chks command, responds with BOOT_RESP_?? result
//=============================================================================
char do_chks(U8 nargs, char* args[], U16 params[], char eprom_select, char* obuf, char verbose, U16* i0){

	char	c = BOOT_RESP_VOID;		// char temp
	char	d;						// char temp
	U8*		ptr0;					// U8 mem pointer
	U8*		ptr1;					// U8 mem pointer#2
	U16		i2;

	c = parm_srch(nargs, args, "S");							// c becomes "S" if S found in args
	if(c){
		nargs--;
	}else{
		c = parm_srch(nargs, args, "C");						// c becomes "C" if C found in args
		if(c){
			nargs--;
		}
	}
	if(eprom_select){											// set start/end defaults
		params[0] = device_eprom_start;							// EPROM
		params[1] = device_eprom_end;
	}else{
		params[0] = device_eeprom_start;						// EEPROM
		params[1] = device_eeprom_end;
	}															// set remaining param defaults:
	params[2] = 0;												// no stor addr
	params[3] = 0;												// crc/chsum initial value
	params[4] = XPOLY;											// crc poly value
	get_Dargs(1, nargs, args, params);							// parse param numerics
	d = BOOT_RESP_OK;											// pre-setok response
	if(!ram_range(params[0], params[1])){						// s/e needs to be in RAM
		d = BOOT_RESP_EPERR;
		if(verbose){
			if(device_valid){
				dev_mem_error(eprom_select);
			}else{
				disp_error(no_device);
			}
		}
	}else{
		if(verbose){
			sprintf(obuf,"parms: %02x %04x, %04x, %04x, %04x, %04x", (U16)c & 0xff, params[0],params[1],params[2],params[3],params[4]);
			puts(obuf);
		}
		i2 = params[3];											// init checksum start
		ptr0 = dut_xdata + params[0] - RAM_START;				// set start/running ptr
		ptr1 = dut_xdata + params[1] - RAM_START;				// set end ptr
		switch(c){
			case 'S':											// do checksum
				do{
					i2 += ((U16)*ptr0) & 0xff;					// add up the data
				}while(ptr0++ != ptr1);							// until end is reached
				if(verbose){
					sprintf(obuf,"CHKSUM = $%04x",i2);			// display result
					puts(obuf);
				}
				if(params[2] >= 0x8000){						// if store address valid, store checksum to mem
					ptr0 = dut_xdata + params[2] - RAM_START;	// calc ptr
					*ptr0++ = (U8)(i2 >> 8);					// store sum
					*ptr0 = (U8)i2;
					if(verbose){
						sprintf(obuf,"Stored @ $%04x",params[2]); // display akn msg
						puts(obuf);
					}
				}
				break;

			default:
			case 'C':											// do crcsum
				do{
					i2 = calcrc(*ptr0, i2, params[4]);			// crc the data
				}while(ptr0++ != ptr1);							// until end is reached
				if(verbose){
					sprintf(obuf,"CRC = $%04x",i2);				// display result
					puts(obuf);
				}
				if(params[2] >= 0x8000){						// if store address valid, store checksum to mem
					ptr0 = dut_xdata + params[2] - RAM_START;	// calc ptr
					*ptr0++ = (U8)(i2 >> 8);					// store crc
					*ptr0 = (U8)(i2 & 0xff);
					if(verbose){
						sprintf(obuf,"Stored @ $%04x",params[2]); // display akn msg
						puts(obuf);
					}
				}
				break;
		}
	*i0 = i2;													// transfer sum back to caller
	}
	return d;
}

//=============================================================================
// do_config command, responds with BOOT_RESP_?? result
//=============================================================================
char do_config(U8 nargs, char* args[], U16 params[], char eprom_select, char* obuf, char verbose){

	char	c = BOOT_RESP_VOID;		// char response (preset as void, which implies interrogate)
	char	d;						// char temp
	U8		i;						// temp
	U8		k;						// temp
	U16		i1;
	U16		i2;

	params[0] = 0xFF00;											// pre-set invalid param
	get_Dargs(1, nargs, args, params);							// process params
	if(!device_eeprom){
		if(verbose) dev_mem_error(eprom_select);				// device has no EEPROM, error
		c = BOOT_RESP_EPERR;									// set no eeprom err,
	}else{
		hc11_waitok(5, 0);										// init waitok response to null
		if(params[0] < 0x100){									// a valid param detected, do pgm
			if(boot_start()){									// reset target
				do_green_led(LED_ON);
				k = config_len();								// get target code length
				for(i = 0; i < k; i++){
					obuf[i] = config[i];						// xfr hc11 code to local buffer
				}
				obuf[i] = (U8)params[0];						// add config value to pgm
				i1 = i2 = (U16)(k + 1) & 0xff;					// update length
				if(boot_len_fixed) i2 = device_max_bootlen;
				c = boot_send(obuf, i1, i2);					// send target code
				d = BOOT_RESP_VOID;								// pre-clear response
				if(c == BOOT_RESP_OK) d = hc11_waitok(0, SEC50MS); // if targ send OK, wait for resp
				if((d != BOOT_RESP_OK) || (c != BOOT_RESP_OK)){	// if not OK, send err msg
					if(verbose){
						disp_fail(obuf, "CONFIG PGM", c, d);
						disp_wait_addr(obuf);
					}
				}
				c |= d;
				do_green_led(LED_OFF);
			}else{
				if(verbose) disp_error(no_response);			// no target response
				c = BOOT_RESP_TO;
			}
		}
	}
	return c;
}

//=============================================================================
// do_bulk command, responds with BOOT_RESP_?? result
//=============================================================================
char do_bulk(char eprom_select, char* obuf, char verbose){

	char	c = BOOT_RESP_VOID;		// char response (preset as void, which implies interrogate)
	char	d;						// char temp
	char*	t;						// char pointer temp
	U8		i;						// temp
	U8		j;						// temp
	U16		i1;
	U16		i2;

	if(!device_eeprom){											// no eeeprom is fatal
		if(verbose) dev_mem_error(eprom_select);
		c = BOOT_RESP_EPERR;
	}else{
		if(boot_start()){										// reset target
			do_green_led(LED_ON);
			j = eebulk_len();									// get xfr length
			for(i = 0; i < j; i++){
				obuf[i] = eebulk[i];							// xfr hc11 code to local buffer
			}
			t = obuf + ((U16)j & 0xff);							// calc end of buffer ptr
			i1 = boot_se(t, device_eeprom_start, device_eeprom_end, device_pprog); // add start/stop addrs (eeprom only)
			i1 += (U16)j & 0xff;								// calc total xfr len
			i2 = i1;
			if(boot_len_fixed) i2 = device_max_bootlen;
			c = boot_send(obuf, i1, i2);						// send HC11 cmd code
			d = 0;
			if(c == BOOT_RESP_OK) d = hc11_waitok(0, SEC50MS);	// wait for response
			if((d == BOOT_RESP_OK) && (c == BOOT_RESP_OK)){
				if(verbose) puts("Device Erased.");				// resp OK,
			}else{
				if(verbose){
					disp_fail(obuf, "Erase", c, d);				// dev. not blank
					disp_wait_addr(obuf);
				}
			}
			c |= d;
			do_green_led(LED_OFF);
		}else{
			if(verbose) disp_error(no_response);				// display err, response
			c = BOOT_RESP_TO;
		}
	}
	return c;
}

//-----------------------------------------------------------------------------
// fill_ram() fills sram ($8000-ffff, or start/end) with fdata
//	if start == end, use $8000-ffff
//	responds with TRUE if fill successfull, else FALSE
//-----------------------------------------------------------------------------
char fill_ram(U8 nargs, char* args[], U16 params[]){

	U8		i;					// temp
	U16		addr;				// start/running addr pointer
	U16		eaddr;				// end addr pointer
	char	v = TRUE;			// response value, pre-set pass

	params[0] = 0xffff;											// preset fill data with invalid value
	params[1] = 0x8000;											// default, start of RAM
	params[2] = 0xffff;											// default, end of ram
	get_Dargs(1, nargs, args, params);							// parse param numerics
	if(params[0] > 0x00ff) i = 0xff;							// if fill value invalid, use default of 0xff
	else i = (U8)params[0];										// else use arg value
	if(ram_range(params[1], params[2])){
		addr = params[1] - RAM_START - 1;						// else use arg values (sub 1 to align w/ loop logic)
		eaddr = params[2] - RAM_START;
		do{
			dut_xdata[++addr] = i;								// fill data over start/end range
			if(dut_xdata[addr] != i) v = FALSE;					// if write fail, set error
		}while(addr != eaddr);
	}else{
		v = FALSE;												// error, address range
	}
	return v;													// return pass/fail (T/F)
}

//-----------------------------------------------------------------------------
// check_ram() checks sram ($8000-ffff) with fdata
//	responds with TRUE if fill verify successfull, else FALSE
//-----------------------------------------------------------------------------
char check_ram(U8 nargs, char* args[], U16 params[]){

	U8		i;					// temp
	U16		addr;				// start/running addr pointer
	U16		eaddr;				// end addr pointer
	char	v = TRUE;			// response value, pre-set pass

	params[0] = 0xffff;											// preset fill data with invalid value
	params[1] = 0x8000;											// default, start of RAM
	params[2] = 0xffff;											// default, end of ram
	get_Dargs(1, nargs, args, params);							// parse param numerics
	if(params[0] > 0x00ff) i = 0xff;							// if fill value invalid, use default of 0xff
	else i = (U8)params[0];										// else use arg value
	if(params[1] == params[2]){									// if start == end, use full RAM defaults for start/end
		addr = 0;
		eaddr = RAM_LEN;
	}else{
		addr = params[1] - RAM_START - 1;						// else use arg values (sub 1 to align w/ loop logic)
		eaddr = params[2] - RAM_START;
	}
	do{															// check data range (start->end)
		if(dut_xdata[addr] != i){								// if data fail, set error
			v = FALSE;			
		}
	}while(++addr != RAM_LEN);
	return v;													// return pass/fail (T/F)
}

//-----------------------------------------------------------------------------
// do_blank() checks device for blank.  user may specify start/end or use device defaults
//	responds with BOOT_RESP_?? result
//-----------------------------------------------------------------------------
char do_blank(U8 nargs, char* args[], U16 params[], char eprom_select, char* obuf, char verbose){

	char c;
	char d;
	U8	i;
	U8	j;
	U16	i0;
	U16	i1;
	U16	i2;
	char* t;

	if(eprom_select){											// set start/end variables
		params[0] = device_eprom_start;							// EPROM
		params[1] = device_eprom_end;
		c = device_eprom;
	}else{
		params[0] = device_eeprom_start;						// EEPROM
		params[1] = device_eeprom_end;
		c = device_eeprom;
	}
	if(!c){
		if(verbose) dev_mem_error(eprom_select);				// if no resource, fatal
		c = BOOT_RESP_ER;
	}else{
		get_Dargs(1, nargs, args, params);						// parse param numerics
		i1 = params[0];
		i2 = params[1];
		if(!ram_range(i1, i2)){
			if(verbose) ram_range_err();
			c = BOOT_RESP_ER;
		}else{
			if(boot_start()){
				i0 = i2 - i1 + 1;								// calc timeout limit based on targ mem size
				i0 = (i0 / 90) + SEC50MS;						// HC11 can check 90.9 bytes/ms (round down)
				j = blank_len();
				for(i = 0; i < j; i++){
					obuf[i] = blank[i];							// xfr hc11 code to local buffer
				}
				t = obuf + ((U16)j & 0xff);						// calc end of buffer ptr
				i1 = boot_se(t, i1, i2, device_pprog);			// add start/stop/pprog addrs
				i1 += (U16)j & 0xff;							// calc xfr len
				i2 = i1;
				if(boot_len_fixed) i2 = device_max_bootlen;
				c = boot_send(obuf, i1, i2);					// xfr hc11 cmd code
				d = BOOT_RESP_VOID;								// pre-clear response
				if(c == BOOT_RESP_OK) d = hc11_waitok(0, i0);	// wait for response
				if((d == BOOT_RESP_OK) && (c == BOOT_RESP_OK)){
					if(verbose) puts("Device is Blank.");		// device is blank
				}else{
					if(verbose){
						disp_fail(obuf, "Blank check", c, d);	// device not blank
						disp_wait_addr(obuf);
					}
					c = BOOT_RESP_ER;
				}
			}else{
				if(verbose) disp_error(no_response);			// display err, no target response
				c = BOOT_RESP_ER;
			}
		}
	}
	return c;
}

//=============================================================================
// do_offs() command, sets offset if a valid numeric, else no change
//=============================================================================
void do_offs(U8 nargs, char* args[], U16 params[], U16* offset){

	char c = FALSE;						// sign, assume +
	
	if(*args[1] == '+'){										// skip '+' sign
		args[1]++;
	}
	if(*args[1] == '-'){										// capture '-' sign
		c = TRUE;
		args[1]++;
	}
	params[0] = *offset;										// default to current value
	get_Dargs(1, nargs, args, params);							// parse param numerics
	if(c){
		if(params[0] < 0x8000){
			*offset = (0xffff - params[0]) + 1;					// if negative, ignore abs values greater than 0x8000
		}
	}else{
		*offset = params[0];									// transfer value
	}
}

//******************************//
// hosekeeping functions follow //
//******************************//

//=============================================================================
// write string to response buffer if there is space remaining
//	Over-writes null-term from previous entry, leaves buffer null terminated.
//=============================================================================
void puts_bcmd(char* string){

	if((bcmd_resp_ptr - bcmd_resp_buf) < MAX_PRESP_BUF){
		while(*string){
			*bcmd_resp_ptr++ = *string++;
		}
	}
	*bcmd_resp_ptr = '\0';										// null terminate (but don't advance pointer)
}

//=============================================================================
// get device id from command line
//	looks through the args[] list to see if the device ID strings are present.
//	Stops searching after first match.
//=============================================================================

U8 get_dev_id(U8 nargs, char* args[]){

	U8 i = 0;													// default is no device

	if(parm_srch(nargs, args, "E9")) i = 9;						// is HC711E9 device
	else{
		if(parm_srch(nargs, args, "E20")) i = 20;				// is HC711E20 device (upper EPROM seg)
		else{
			if(parm_srch(nargs, args, "LE20")) i = 19;			// is HC711E20 device (lower EPROM seg)
			else{
				if(parm_srch(nargs, args, "E32")) i = 32;		// is HC711E32 device
				else{
					if(parm_srch(nargs, args, "E2")) i = 2;		// is HC811E2 device
					else{
						if(parm_srch(nargs, args, "D3")) i = 3;	// is HC711d3 device
					}
				}
			}
		}
	}
	return i;
}

//=============================================================================
// get numeric params from command line args
//	argsrt specifies the first item to be searched and aligns argsrt with params[0]
//	for multi-arg cmds, fields must be entered in order.
//=============================================================================
U8 get_Dargs(U8 argsrt, U8 nargs, char* args[ARG_MAX], U16 params[8]){

	char*	s;
	U16*	ptr1;
	U8		i;
	U8		count = 0;

	if(argsrt < nargs){											// test for start in limit (abort if not)
		for(i = argsrt; i < nargs; i++){						// convert strings to values
			s = args[i];										// set pointers to array items
			ptr1 = &params[i - argsrt];
			switch(*s){
				case '-':										// skip if user specified default
				case '\0':										// or if arg is empty
					break;

				default:
					count += sscanf(s,"%x",ptr1);				// get hex value
					break;

				case '=':
					s++;
					count += sscanf(s,"%d",ptr1);				// get decimal if leading "="
					break;
			}
		}
	}
	return count;
}

//=============================================================================
// search for command keywords, return cmd ID if found
//	uses the cmd_list[] array which is constructed as an array of null terminated
//	strings compressed into a single string definition.  Commands are added by
//	placing the minimum required text from the command name with a '\0' terminating
//	null.  cmd_list[] is terminated by an $ff after all of the command names.
//	cmd_enum{} holds an enumerated, named list of all valid commands.  The enum
//	definition must be at the top of this file, so the commented-out version shown
//	below must be copied and pasted to the top of the file whan any changes are
//	made (commands added or deleted).
//
//	Some thought must be put into the order of command names.  Shorter matching
//	names (e.g., single chr entries) must follow longer names to allow the algortihm
//	to properly trap the shorter cmd name.
//	
//=============================================================================
cmd_type cmd_srch(char* string){
// dummy end of list, used to break out of search loop
const char end_list[] = {0xff};
// list of minimum length command words. cmd words are separated by '\0' and list terminated with 0xff
const char cmd_list[] = {"DE\0CO\0U\0CH\0C\0BU\0B\0PGM\0D\0TEST1\0TEST2\0S0\0O\0F\0M\0?\0H\0VERS\0V\0\xff"};
//enum cmd_enum{	device,copy,upl,checks,config_c,bulk_c,blank_c,pgm,downl,tst1,tst2,s0parse,offset_c,fill,mem_wr,help1,help2,vers,verify,lastcmd,helpcmd };
//!!! make changes to cmd_enum here, move them to top of file, then un-comment !!!

	char*	ptr;							// temp ptr
	char	cmdid = 0;						// start at beginning of cmd_enum
	char	i;								// temp
	char	found = FALSE;					// cmd found flag (default to not found)

	ptr = cmd_list;												// start at beginning of serach list
	while((*ptr & 0x80) != 0x80){								// process until 0xff found in search list
		i = strncmp(string, ptr, strlen(ptr));					// inbound string match search list?
		if(i){
			cmdid++;											// no, advance to next cmdid 
			while(*ptr++);										// skip to next item in search list
		}else{
			ptr = end_list;										// found match,
			found = TRUE;										// set break-out criteria
		}
	}
	if(!found) cmdid = lastcmd;									// not found, set error cmd id
	return cmdid;
}

//=============================================================================
// parm_srch() looks for a match of parm_str in any non-empty args[] strings
//	if found, remove the args entry from param list and return 1st chr of parm_str,
//	else return '\0'
//=============================================================================
char parm_srch(U8 nargs, char* args[ARG_MAX], char* parm_str){

	U8		i;								// counter temp
	char	c = '\0';						// first chr of matched parm_str (first time thru loop, there is no match)
	static char null_str[] = "";			// null string that persists
	
    for(i = 1; i <= nargs; i++){								// search starting with first args[] item
		if(c){													// if(c!=null)...
			args[i] = args[i+1];								// if there was a match, move the subsequent pointers down one
		}else{
			if(strlen(parm_str) == strlen(args[i])){			// in order to match, the lengths have to be equal...
				if(strncmp(args[i], parm_str, strlen(parm_str)) == 0){ // look for match
					c = *parm_str;								// if match, capture 1st chr in matched string
					i--;										// back-up one to edit this item out of the list
				}
			}
		}
    }
 	if(c != '\0'){
		args[ARG_MAX - 1] = null_str;							// if there was a match, the last pointer goes to null
		
	}
	return c;													// return first chr in matched string, or null if no match
}

//=============================================================================
// dev_sel() process device select ID
//	2 = HC811E2
//	3 = HC711D3
//	9 = HC711E9
//	19 = HC711E20 (lower EPROM segment)
//	20 = HC711E20 (upper EPROM segment)
//	32 = HC711E32
//	returns TRUE if valid, else FALSE
//	Sets device specific variables (DSVs) according to the numeric devid as
//	described above.  Any devid other than those listed above results in
//	"NO DEVICE" attributes being placed into the DSVs
//=============================================================================
char dev_sel(U8 devid){

	char c = FALSE;

	switch(devid){
		case 2:
			device_eprom = FALSE;					// HC811E2, no EPROM, 2K EEPROM
			device_eeprom = TRUE;
			device_eprom_start = 0;
			device_eprom_end = 0;
			device_eeprom_start = 0xf800;
			device_eeprom_end = 0xffff;
			device_type = 2;
			device_valid = TRUE;
			boot_len_fixed = TRUE;
			device_max_bootlen = 256;
			device_pprog = 0x103B;
			c = TRUE;
			dut_pwr(TARGET_ON);
			break;

		case 3:
			device_eprom = TRUE;					// HC711D3, 4K EPROM, no EEPROM
			device_eeprom = FALSE;
			device_eprom_start = 0xf000;
			device_eprom_end = 0xffff;
			device_eeprom_start = 0;
			device_eeprom_end = 0;
			device_type = 3;
			device_valid = TRUE;
			boot_len_fixed = FALSE;
			device_max_bootlen = 192;
			device_pprog = 0x003B;
			c = TRUE;
			dut_pwr(TARGET_ON);
			break;

		case 9:
			device_eprom = TRUE;					// HC711E9, 12K EPROM, 512 bytes EEPROM
			device_eeprom = TRUE;
			device_eprom_start = 0xd000;
			device_eprom_end = 0xffff;
			device_eeprom_start = 0xb600;
			device_eeprom_end = 0xb7ff;
			device_type = 9;
			device_valid = TRUE;
			boot_len_fixed = FALSE;
			device_max_bootlen = 512;
			device_pprog = 0x103B;
			c = TRUE;
			dut_pwr(TARGET_ON);
			break;

		case 19:
			device_eprom = TRUE;					// HC711E20 low segment, 8K EPROM, 512 bytes EEPROM
			device_eeprom = TRUE;
			device_eprom_start = 0x9000;			// eprom on this device is segmented...this is low seg
			device_eprom_end = 0xafff;
			device_eeprom_start = 0xb600;
			device_eeprom_end = 0xb7ff;
			device_type = 20;
			device_valid = TRUE;
			boot_len_fixed = FALSE;
			device_max_bootlen = 768;
			device_pprog = 0x1036;
			c = TRUE;
			dut_pwr(TARGET_ON);
			break;

		case 20:
			device_eprom = TRUE;					// HC711E20, 20K EPROM, 512 bytes EEPROM
			device_eeprom = TRUE;
			device_eprom_start = 0xd000;			// eprom on this device is segmented...this is high seg
			device_eprom_end = 0xffff;
			device_eeprom_start = 0xb600;
			device_eeprom_end = 0xb7ff;
			device_type = 20;
			device_valid = TRUE;
			boot_len_fixed = FALSE;
			device_max_bootlen = 768;
			device_pprog = 0x1036;
			c = TRUE;
			dut_pwr(TARGET_ON);
			break;

		case 32:
			device_eprom = TRUE;					// HC711E32, 32K EPROM, 512 bytes EEPROM
			device_eeprom = TRUE;
			device_eprom_start = 0xd000;
			device_eprom_end = 0xffff;
			device_eeprom_start = 0xb600;
			device_eeprom_end = 0xb7ff;
			device_type = 32;
			device_valid = TRUE;
			boot_len_fixed = FALSE;
			device_max_bootlen = 2048;
			device_pprog = 0x103B;
			c = TRUE;
			dut_pwr(TARGET_ON);
			break;

		default:
		case NO_DEVICE:
			device_eprom = FALSE;					// no device
			device_eeprom = FALSE;
			device_eprom_start = 0;
			device_eprom_end = 0;
			device_eeprom_start = 0;
			device_eeprom_end = 0;
			device_valid = FALSE;
			device_type = NO_DEVICE;
			boot_len_fixed = TRUE;
			device_max_bootlen = 0;
			device_pprog = 0x0000;
			dut_pwr(TARGET_OFF);
			break;

	}
	return c;
}

//=============================================================================
// dev_itg() displays device ID based on current settings
//=============================================================================
void dev_itg(char* obuf){

	U8 i = NO_DEVICE;
	
	if(device_valid){
		i = device_type;
	}
	switch(i){
		case 2:
			putss("HC811E2");						// HC811E2, no EPROM, 2K EEPROM
			break;

		case 3:
			putss("HC711D3");						// HC711D3, 4K EPROM, no EEPROM
			break;

		case 9:
			putss("HC711E9");						// HC711E9, 12K EPROM, 512 bytes EEPROM
			break;

		case 19:
			putss("HC711E20low");					// HC711E20, 8K EPROM, 512 bytes EEPROM
			break;

		case 20:
			putss("HC711E20");						// HC711E20, 12K EPROM, 512 bytes EEPROM
			break;

		case 32:
			putss("HC711E32");						// HC711E32, 32K EPROM, 512 bytes EEPROM
			break;

		default:
		case NO_DEVICE:								// no device...
			putss("NO DEVICE");
			break;

	}
	if(dut_pwr(TARGET_STAT)){
		puts(", Dev ON");
	}else{
		puts(", Dev off");
	}
	if(i != NO_DEVICE){
		if(device_eprom){							// no device
			sprintf(obuf,"EPROM Start/End:  $%04x/$%04x",device_eprom_start,device_eprom_end);
			puts(obuf);
		}else{
			puts("No EPROM");
		}
		if(device_eeprom){							// no device
			sprintf(obuf,"EEPROM Start/End: $%04x/$%04x",device_eeprom_start,device_eeprom_end);
			puts(obuf);
		}else{
			puts("No EEPROM");
		}
		sprintf(obuf,"bootlen:   $%04x, ",(U16)device_max_bootlen);
		putss(obuf);
		if(boot_len_fixed){
			puts("fixed");
		}else{
			puts("var");
		}
		sprintf(obuf,"REG addrs: $%04x",device_pprog & 0xff00);
		puts(obuf);
	}
}

//=============================================================================
// convert all chrs in string to upper case
//=============================================================================
void str_toupper(char *string){

    while(*string != '\0'){
        *string++ = toupper(*string);
    }
}

//=============================================================================
//
// parse string for delimited arguments
//  on exit, the args[] array holds each delimited argument from the command string input:
//  args[0] holds first arg (command)
//  args[1] holds next arg
//  args[2] etc...
//  up to args[ARG_MAX]
//
//  nargs holds number of arguments collected.  i.e., nargs = 3 specifies that args[0] .. args[3]
//      all hold arguments (three total, including the command).
//
//=============================================================================
int parse_args(char* cmd_string, char* args[ARG_MAX]){

	int i;
	char quote_c = 0;
	static char null_string[2] = "";

    // clear args pointers
    for (i=0; i<ARG_MAX; i++){
        args[i] = null_string;
    }
    i = 0;
    do{
        if(quotespace(*cmd_string, 0)){         // process quotes until end quote or end of string
            quote_c = *cmd_string;              // close quote must = open quote
            args[i++] = ++cmd_string;               // start args with 1st char after quote
            while(!quotespace(*cmd_string,quote_c)){
                if(*cmd_string == '\0'){
                    return i;                   // end of cmd string, exit
                }
                cmd_string++;
            }
            *cmd_string++ = '\0';               // replace end quote with null
        }
        if(*cmd_string == '\0'){
            return i;                           // end of cmd string, exit
        }
        if(!whitespace(*cmd_string)){
            args[i++] = cmd_string++;			// when non-whitespace encountered, assign arg[] pointer
            if(i > ARG_MAX){
                return i;						// until all args used up
            }
            do{
                if(*cmd_string == '\0'){
                    return i;                   // end of cmd string, exit
                }
                if(whitespace(*cmd_string)){
                    *cmd_string = '\0';			// then look for next whitespace and delimit (terminate) the arg[] string
                    break;
                }
                cmd_string++;					// loop until end of cmd_string or next whitespace
            } while (1);
        }
        cmd_string++;							// loop...
    } while (1);
}

//=============================================================================
// test characer for whitespace
//=============================================================================
int whitespace(char c){

    switch (c){					// These are all valid whitespace:
        case '\n':          	// newline
        case '\r':          	// cr
        case '\t':          	// tab
        case 0x20:{         	// space
		case '/':				// slash is also wsp
            return TRUE;
        }
    }
    return FALSE;
}

//=============================================================================
// test characer for quote
//=============================================================================
int quotespace(char c, char qu_c){

    if(qu_c == '\0'){
        switch (c){				// if qu_c is null, these are valid quotes:
            case '\'':          // newline
            case '\"':          // cr
            case '\`':          // tab
                return TRUE;
            }
    } else {
        if(c == qu_c){			// else, only qu_c results in a TRUE match
            return TRUE;
        }
    }
    return FALSE;
}

//=============================================================================
// display appropriate device mem error.  Saves memory since these strings
//	happen a lot.
//=============================================================================
void dev_mem_error(char eprom_select){

	if(eprom_select){
		puts("No device EPROM");
	}else{
		puts("No device EEPROM");
	}
}

//=============================================================================
// boot_se() add start/stop and PPROG data to bptr (6 bytes).  Uses passed
//	params for all.  Returns the number of bytes placed (always the same)
//=============================================================================
U16 boot_se(U8* bptr, U16 start, U16 end, U16 ppaddr){

	*bptr++ = (U8)(start >> 8);			// add start
	*bptr++ = (U8)(start & 0xff);
	*bptr++ = (U8)(end >> 8);			// add end
	*bptr++ = (U8)(end & 0xff);
	*bptr++ = (U8)(ppaddr >> 8);		// add "PPROG" addr
	*bptr = (U8)(ppaddr & 0xff);
	return 6;
}

//=============================================================================
// gas_gage() display up to 16 "*" chrs based on count rate.
//	Gauge appearance:
//	[****************]	all OK
//	[***.............]	errors detected
//
//	"len" cmds:
//	0: process gauge counter/display
//	1: set gauge error character = "."
//	2: disable gage counter/display (set clen = 0)
//	all others: set creset = count = len/16, display initial gauge characters
//	This calculation identifies how many bytes are in 1/16th of the total
//	byte count (len).  For count events (len == 0), this Fn decrements count, &
//	displays a gauge chr when count == 0.  count is then reloaded with creset.
//	process continues until 16 gauge chrs have been displayed.  After this,
//	any further count eventss result in no further change to the display.
//=============================================================================
U8 gas_gage(U16 len){

#define LENCMD_MAX 2		// max # of gas-gage() cmds

	static U16	creset;		// holding reg for data counter reset value
	static U16	count;		// data counter
	static U8	clen;		// gage chr counter
	static U8	gchr;		// gage chr storage
		   U8	c = 0;		// gage printed flag

	if(len <= LENCMD_MAX){
		if(!len && clen){
			if(--count == 0){ 
				putchar(gchr);					// disp gage chr
				count = creset;					// reset loop counters
				clen--;
				if(clen == 0) putchar(']');		// if end of gage, print end bracket
				c = 1;
			}
		}else{
			if(len == 1) gchr = '.';			// if error flag, change gauge chr to err mode
			if(len == 2) clen = 0;				// disable gauge
		}
	}else{
		creset = count = len >> 4;				// init count & count reset (creset) = len/16
		if(creset == 0) creset = 1;				// if overall length too short, set 1:1
		clen = 16;								// 16 gage chrs max
		gchr = '*';								// set * as gage chr
		putchar('[');							// print start bracket
		for(c = 0; c < 16; c++) putchar(' ');
		putchar(']');							// place end bracket for scale
		for(c = 0; c < 17; c++) putchar('\b');	// backspace to start of scale
		c = 1;
	}
	return c;
}

//=============================================================================
// log_error_byte() places error data into log buffer.  Log format is:
//	(device) (host) (addrH) (addrL).  Called by target verify fns to allow
//	a limited number of errors to be trapped (limit is the buffer used to
//	hold the error log).
//	returns updated pointer to next available log entry
//=============================================================================
U8* log_error_byte(U8* lbuf, U8 d, U8 h, U16 a){

	*lbuf++ = d;								// store device data
	*lbuf++ = h;								// store host data
	*lbuf++ = (U8)(a >> 8);						// store addr
	*lbuf++ = (U8)(a & 0xff);
	return lbuf;								// return updated pointer
}

//=============================================================================
// disp_error_log() displays errors logged into error string.  Log format is:
//	(device) (host) (addrH) (addrL)
//	Display format is:
//	nn: Dev ($xx) != $xx @$xxxx\n = 28 printed chrs
//	nn = err number (ordinal)
//	xx = data bytes
//	xxxx = error address
//=============================================================================
void disp_error_log(U8* lbuf, U16 len){

	char obuf[32];				// local buffer
	// use U16 type to simplify sprintf variable list
	U16  i;						// loop counter
	U16  d;						// device data
	U16  h;						// host data
	U16  a;						// addr

	len++;										// add 1 to end so that we can start loop at "1"
	for(i = 1; i < len; i++){					// loop from 1 to len+1 entries
		d = (U16)*lbuf++ & 0xff;				// format device data
		h = (U16)*lbuf++ & 0xff;				// format host data
		a = ((U16)*lbuf++ & 0xff) << 8;			// format addr
		a |= (U16)*lbuf++ & 0xff;
		sprintf(obuf,"%02u: Dev ($%02x) != $%02x @$%04x", i, d, h, a); // display err line
		puts(obuf);
	}
}

//=============================================================================
// bcmd_resp_init() inits bcmd_resp_ptr
//=============================================================================
void bcmd_resp_init(void){

	bcmd_resp_ptr = bcmd_resp_buf;
	*bcmd_resp_ptr = '\0';
}

//=============================================================================
// ram_range() checks start/end for in RAM limits (TRUE) else (FALSE)
//=============================================================================
char ram_range(U16 start, U16 end){

	char c = TRUE;		// return result
	
	// validate start/end, use full RAM defaults if:
	//	end < start
	//	end < RAM_START
	//	start < RAM_START
	if((start < RAM_START) || (end < RAM_START) || (end < start)){
		c = FALSE;
	}
	return c;
}

//=============================================================================
// ram_range_error() displays mem range err msg
//=============================================================================
void ram_range_err(void){

	puts("Memory range error.");
}
