FFPGMR11.uvproj is the Keil project file.

For non-Keil compilers, create a Project for the C8051F34C (SiLabs) and
add all of the ".c" files that appear in this directory.

Refer to "C" files for project commentary.

FF-PGMR11_intosc.cwg (ConfigWizard2 file) contains processor configuration
for this project. Visit www.silabs.com for the latest version of ConfigWizard2
application.  The output of the config wizard is copied into initdevice.c.
Note: Depending on your compiler installation, it may be necessary to edit
the header files that are included in the ConfigWizard output.

Joe Haas
joeh@rollanet.org
KE0FF
12/16/2013
